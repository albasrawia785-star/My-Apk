package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = AppRepository(db.appDao())

    // Active User session state
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    // Temporary flag for first login password change flow
    private val _mustChangePasswordUser = MutableStateFlow<User?>(null)
    val mustChangePasswordUser: StateFlow<User?> = _mustChangePasswordUser.asStateFlow()

    // System flows
    val allUsers: StateFlow<List<User>> = repository.getAllUsersFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allDrugs: StateFlow<List<Drug>> = repository.getAllDrugsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCompanies: StateFlow<List<Company>> = repository.getAllCompaniesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCategories: StateFlow<List<Category>> = repository.getAllCategoriesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSalesBills: StateFlow<List<SaleBill>> = repository.getAllSalesBillsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLogs: StateFlow<List<OperationLog>> = repository.getAllLogsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Settings flows
    val pharmacyName: StateFlow<String> = repository.getSettingFlow("pharmacy_name")
        .map { it?.value ?: "دوائي للمستلزمات الطبية" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "دوائي للمستلزمات الطبية")

    val isDarkMode: StateFlow<Boolean> = repository.getSettingFlow("is_dark_mode")
        .map { it?.value?.toBoolean() ?: false }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val logoIndex: StateFlow<Int> = repository.getSettingFlow("logo_index")
        .map { it?.value?.toIntOrNull() ?: 0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // UI feedback states
    private val _uiMessage = MutableSharedFlow<String>()
    val uiMessage = _uiMessage.asSharedFlow()

    init {
        // Run database seeding on start
        viewModelScope.launch(Dispatchers.IO) {
            seedDatabase()
        }
    }

    private suspend fun seedDatabase() {
        // 1. Seed default Users if empty
        val adminUser = repository.getUser("ali")
        if (adminUser == null) {
            val hashed = hashPassword("ali")
            repository.insertUser(
                User(
                    username = "ali",
                    passwordHash = hashed,
                    role = "ADMIN",
                    canAddDrug = true,
                    canEditDrug = true,
                    canDeleteDrug = true,
                    canDeleteSale = true,
                    mustChangePassword = true // Force password change on first run
                )
            )
        }

        // 2. Seed default categories if empty
        repository.getAllCategoriesFlow().first().let { currentList ->
            if (currentList.isEmpty()) {
                val defaultCats = listOf("مضادات حيوية", "مسكنات ألم", "فيتامينات ومكملات", "أدوية السكري", "أدوية الضغط", "شرابات السعال")
                for (cat in defaultCats) {
                    repository.insertCategory(Category(name = cat))
                }
            }
        }

        // 3. Seed default companies if empty
        repository.getAllCompaniesFlow().first().let { currentList ->
            if (currentList.isEmpty()) {
                val defaultComps = listOf("أكاي (Acai)", "بايونير (Pioneer)", "أو لابس (Awamedica)", "الحكمة (Hikma)", "برستول (Bristol)")
                for (comp in defaultComps) {
                    repository.insertCompany(Company(name = comp, details = "شركة مصنعة للأدوية"))
                }
            }
        }

        // 4. Seed a few starter medicines if empty
        repository.getAllDrugsFlow().first().let { currentList ->
            if (currentList.isEmpty()) {
                val starterDrugs = listOf(
                    Drug(
                        arabicName = "بندول اكسترا",
                        scientificName = "Paracetamol + Caffeine",
                        companyName = "بايونير (Pioneer)",
                        categoryName = "مسكنات ألم",
                        strength = "500mg / 65mg",
                        dosageForm = "أقراص",
                        batchNumber = "B2026",
                        productionDate = "2026-01-01",
                        expiryDate = "2028-12-31",
                        purchasePrice = 1500.0,
                        salePrice = 2500.0,
                        quantity = 50,
                        minLimit = 10,
                        barcode = "6221234567890",
                        notes = "مسكن للألم وخافض للحرارة"
                    ),
                    Drug(
                        arabicName = "أموكسيسيلين",
                        scientificName = "Amoxicillin",
                        companyName = "أو لابس (Awamedica)",
                        categoryName = "مضادات حيوية",
                        strength = "500mg",
                        dosageForm = "كبسول",
                        batchNumber = "AM771",
                        productionDate = "2026-02-15",
                        expiryDate = "2028-02-15",
                        purchasePrice = 2000.0,
                        salePrice = 3500.0,
                        quantity = 8, // Triggers low stock alert
                        minLimit = 10,
                        barcode = "6229876543210",
                        notes = "مضاد حيوي واسع الطيف"
                    ),
                    Drug(
                        arabicName = "فيتامين سي فوار",
                        scientificName = "Vitamin C",
                        companyName = "أكاي (Acai)",
                        categoryName = "فيتامينات ومكملات",
                        strength = "1000mg",
                        dosageForm = "أقراص فوارة",
                        batchNumber = "VC110",
                        productionDate = "2025-06-01",
                        expiryDate = "2026-06-01", // Already expired (for testing)
                        purchasePrice = 1200.0,
                        salePrice = 2000.0,
                        quantity = 30,
                        minLimit = 5,
                        barcode = "6224567890123",
                        notes = "داعم للمناعة"
                    )
                )
                for (drug in starterDrugs) {
                    try {
                        repository.insertDrug(drug)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    // --- Authentication ---
    fun login(username: String, passwordHashOrRaw: String, isRaw: Boolean = true) {
        viewModelScope.launch {
            val inputHash = if (isRaw) hashPassword(passwordHashOrRaw) else passwordHashOrRaw
            val user = repository.getUser(username)
            if (user != null && user.passwordHash == inputHash) {
                if (user.mustChangePassword) {
                    _mustChangePasswordUser.value = user
                } else {
                    _currentUser.value = user
                    _uiMessage.emit("تم تسجيل الدخول بنجاح كـ ${user.username}")
                    logOperation(user.username, "", "", "تسجيل دخول", "تم تسجيل دخول المستخدم")
                }
            } else {
                _uiMessage.emit("اسم المستخدم أو كلمة المرور غير صحيحة!")
            }
        }
    }

    fun changePassword(username: String, newPasswordRaw: String) {
        viewModelScope.launch {
            val user = repository.getUser(username)
            if (user != null) {
                val newHash = hashPassword(newPasswordRaw)
                val updatedUser = user.copy(passwordHash = newHash, mustChangePassword = false)
                repository.updateUser(updatedUser)
                _mustChangePasswordUser.value = null
                _currentUser.value = updatedUser
                _uiMessage.emit("تم تغيير كلمة المرور بنجاح ودخول النظام")
                logOperation(updatedUser.username, "", "", "تغيير كلمة المرور", "تم تغيير كلمة المرور للمستخدم عند أول دخول")
            }
        }
    }

    fun logout() {
        val user = _currentUser.value
        if (user != null) {
            viewModelScope.launch {
                logOperation(user.username, "", "", "تسجيل خروج", "تم تسجيل خروج المستخدم")
            }
        }
        _currentUser.value = null
    }

    // --- User Management ---
    fun registerUser(user: User) {
        viewModelScope.launch {
            repository.insertUser(user)
            _uiMessage.emit("تمت إضافة المستخدم ${user.username} بنجاح")
            currentUser.value?.let {
                logOperation(it.username, "", "", "إضافة مستخدم", "تم تسجيل مستخدم جديد باسم ${user.username}")
            }
        }
    }

    fun updateUser(user: User) {
        viewModelScope.launch {
            repository.updateUser(user)
            _uiMessage.emit("تم تحديث بيانات المستخدم ${user.username}")
            currentUser.value?.let {
                logOperation(it.username, "", "", "تحديث مستخدم", "تم تحديث الصلاحيات للمستخدم ${user.username}")
            }
        }
    }

    fun deleteUser(user: User) {
        viewModelScope.launch {
            repository.deleteUser(user)
            _uiMessage.emit("تم حذف المستخدم ${user.username}")
            currentUser.value?.let {
                logOperation(it.username, "", "", "حذف مستخدم", "تم حذف المستخدم ${user.username}")
            }
        }
    }

    // --- Drug Management ---
    fun addDrug(drug: Drug, onResult: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            // Check barcode duplicate
            val existing = repository.getDrugByBarcode(drug.barcode)
            if (existing != null) {
                _uiMessage.emit("خطأ: باركود الدواء مكرر ومسجل مسبقاً باسم (${existing.arabicName})")
                onResult(false)
            } else {
                try {
                    repository.insertDrug(drug)
                    _uiMessage.emit("تمت إضافة الدواء (${drug.arabicName}) بنجاح")
                    currentUser.value?.let {
                        logOperation(it.username, drug.barcode, drug.arabicName, "إضافة", "إضافة دواء جديد للمخزن")
                    }
                    onResult(true)
                } catch (e: Exception) {
                    _uiMessage.emit("خطأ أثناء الإضافة: ${e.message}")
                    onResult(false)
                }
            }
        }
    }

    fun updateDrug(drug: Drug, onResult: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            try {
                // Confirm barcode uniqueness for another item
                val existing = repository.getDrugByBarcode(drug.barcode)
                if (existing != null && existing.id != drug.id) {
                    _uiMessage.emit("خطأ: باركود الدواء مكرر ومسجل مسبقاً للدواء (${existing.arabicName})")
                    onResult(false)
                } else {
                    repository.updateDrug(drug)
                    _uiMessage.emit("تم تحديث بيانات الدواء (${drug.arabicName})")
                    currentUser.value?.let {
                        logOperation(it.username, drug.barcode, drug.arabicName, "تعديل", "تحديث بيانات الدواء في المخزن")
                    }
                    onResult(true)
                }
            } catch (e: Exception) {
                _uiMessage.emit("خطأ أثناء التحديث: ${e.message}")
                onResult(false)
            }
        }
    }

    fun deleteDrug(drug: Drug) {
        viewModelScope.launch {
            try {
                repository.deleteDrug(drug)
                _uiMessage.emit("تم حذف الدواء (${drug.arabicName}) نهائياً")
                currentUser.value?.let {
                    logOperation(it.username, drug.barcode, drug.arabicName, "حذف", "حذف الدواء من قاعدة البيانات")
                }
            } catch (e: Exception) {
                _uiMessage.emit("خطأ أثناء الحذف: ${e.message}")
            }
        }
    }

    // --- Companies ---
    fun addCompany(name: String) {
        viewModelScope.launch {
            if (name.isBlank()) return@launch
            repository.insertCompany(Company(name = name.trim()))
            _uiMessage.emit("تمت إضافة الشركة ($name)")
        }
    }

    fun deleteCompany(company: Company) {
        viewModelScope.launch {
            repository.deleteCompany(company)
            _uiMessage.emit("تم حذف الشركة (${company.name})")
        }
    }

    // --- Categories ---
    fun addCategory(name: String) {
        viewModelScope.launch {
            if (name.isBlank()) return@launch
            repository.insertCategory(Category(name = name.trim()))
            _uiMessage.emit("تم إضافة التصنيف ($name)")
        }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            repository.deleteCategory(category)
            _uiMessage.emit("تم حذف التصنيف (${category.name})")
        }
    }

    // --- Transaction Actions (Sale & Purchase) ---
    fun sellDrugByBarcode(barcode: String, quantity: Int, onResult: (Boolean, Drug?, String) -> Unit) {
        viewModelScope.launch {
            val drug = repository.getDrugByBarcode(barcode)
            if (drug == null) {
                playBeep()
                triggerVibration()
                onResult(false, null, "الدواء غير موجود في قاعدة البيانات.")
                return@launch
            }
            if (drug.isArchived) {
                onResult(false, drug, "عذراً، هذا الدواء مؤرشف وغير متاح للبيع.")
                return@launch
            }
            if (drug.quantity <= 0) {
                onResult(false, drug, "عذراً، نفد مخزون الدواء (${drug.arabicName}).")
                return@launch
            }
            if (drug.quantity < quantity) {
                onResult(false, drug, "الكمية المطلوبة ($quantity) أكبر من الكمية المتوفرة بالمخزن (${drug.quantity}).")
                return@launch
            }

            // Perform Sale
            val user = _currentUser.value?.username ?: "ali"
            val total = drug.salePrice * quantity
            val invoiceNo = "INV-" + System.currentTimeMillis().toString().takeLast(6)

            val bill = SaleBill(
                invoiceNumber = invoiceNo,
                drugId = drug.id,
                drugName = drug.arabicName,
                quantity = quantity,
                unitPrice = drug.salePrice,
                totalPrice = total,
                username = user
            )

            // Deduct stock
            val newQty = drug.quantity - quantity
            val updatedDrug = drug.copy(quantity = newQty)
            repository.updateDrug(updatedDrug)
            repository.insertSaleBill(bill)

            playBeep()
            triggerVibration()

            // Prepare Feedback Notifications
            var alertMsg = ""
            if (newQty == 0) {
                alertMsg = "⚠️ تنبيه: نفد مخزون الدواء (${drug.arabicName}) بالكامل!"
            } else if (newQty < drug.minLimit) {
                alertMsg = "⚠️ تنبيه: كمية الدواء (${drug.arabicName}) أقل من الحد الأدنى المقدر بـ ${drug.minLimit}!"
            }

            _uiMessage.emit("تمت عملية البيع بنجاح للفاتورة $invoiceNo." + if (alertMsg.isNotEmpty()) " $alertMsg" else "")
            logOperation(user, drug.barcode, drug.arabicName, "بيع", "بيع كمية ($quantity) بقيمة ($total د.ع). الفاتورة: $invoiceNo")
            onResult(true, updatedDrug, "تمت العملية بنجاح! $alertMsg")
        }
    }

    fun addStockQuantityByBarcode(barcode: String, addQuantity: Int, optionalPurchasePrice: Double?, onResult: (Boolean, Drug?, String) -> Unit) {
        viewModelScope.launch {
            val drug = repository.getDrugByBarcode(barcode)
            if (drug == null) {
                onResult(false, null, "الدواء غير موجود في قاعدة البيانات.")
                return@launch
            }

            val user = _currentUser.value?.username ?: "ali"
            val newQty = drug.quantity + addQuantity
            val newPurchasePrice = optionalPurchasePrice ?: drug.purchasePrice

            val updatedDrug = drug.copy(quantity = newQty, purchasePrice = newPurchasePrice)
            repository.updateDrug(updatedDrug)

            playBeep()
            triggerVibration()

            _uiMessage.emit("تمت إضافة كمية ($addQuantity) للدواء (${drug.arabicName}) بنجاح.")
            logOperation(user, drug.barcode, drug.arabicName, "شراء", "إضافة كمية ($addQuantity) وتحديث المخزون ليصبح ($newQty)")
            onResult(true, updatedDrug, "تمت إضافة الكمية بنجاح.")
        }
    }

    fun deleteSaleBill(bill: SaleBill) {
        viewModelScope.launch {
            val user = _currentUser.value
            if (user == null || user.role != "ADMIN") {
                _uiMessage.emit("عذراً، هذا الإجراء متاح للمدير فقط!")
                return@launch
            }

            // Restore stock quantity
            val drug = repository.getDrugById(bill.drugId)
            if (drug != null) {
                val restoredQty = drug.quantity + bill.quantity
                repository.updateDrug(drug.copy(quantity = restoredQty))
            }

            repository.deleteSaleBill(bill)
            _uiMessage.emit("تم حذف الفاتورة ${bill.invoiceNumber} وإعادة الكمية للمخزن.")
            logOperation(user.username, "", bill.drugName, "حذف فاتورة", "حذف فاتورة رقم ${bill.invoiceNumber} وإعادة ${bill.quantity} حبة للمخزون")
        }
    }

    // --- Barcode Generator ---
    fun generateUniqueBarcodeForDrug(drugId: Int, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val drug = repository.getDrugById(drugId)
            if (drug == null) return@launch

            // Generate unique 13 digit barcode starting with Iraqi country code mapping e.g. "622"
            var uniqueBarcode = ""
            var attempts = 0
            while (attempts < 10) {
                val randDigits = (100000000..999999999).random().toString()
                val potentialBarcode = "622$randDigits"
                val existing = repository.getDrugByBarcode(potentialBarcode)
                if (existing == null) {
                    uniqueBarcode = potentialBarcode
                    break
                }
                attempts++
            }

            if (uniqueBarcode.isNotEmpty()) {
                repository.updateDrug(drug.copy(barcode = uniqueBarcode))
                _uiMessage.emit("تم توليد باركود تلقائي فريد للدواء (${drug.arabicName})")
                currentUser.value?.let {
                    logOperation(it.username, uniqueBarcode, drug.arabicName, "إنشاء باركود", "توليد باركود تلقائي فريد")
                }
                onResult(uniqueBarcode)
            } else {
                _uiMessage.emit("فشل توليد الباركود، يرجى المحاولة لاحقاً")
            }
        }
    }

    // --- Logging Helper ---
    private suspend fun logOperation(
        username: String,
        barcode: String,
        drugName: String,
        operationType: String,
        details: String
    ) {
        repository.insertLog(
            OperationLog(
                username = username,
                barcode = barcode,
                drugName = drugName,
                operationType = operationType,
                details = details
            )
        )
    }

    // --- System Settings Management ---
    fun updatePharmacyName(newName: String) {
        viewModelScope.launch {
            repository.insertSetting(SystemSetting("pharmacy_name", newName))
            _uiMessage.emit("تم تعديل اسم الصيدلية بنجاح")
        }
    }

    fun toggleDarkMode(dark: Boolean) {
        viewModelScope.launch {
            repository.insertSetting(SystemSetting("is_dark_mode", dark.toString()))
        }
    }

    fun updateLogoIndex(index: Int) {
        viewModelScope.launch {
            repository.insertSetting(SystemSetting("logo_index", index.toString()))
        }
    }

    // --- Sound and Haptic Feedback Utilities ---
    fun playBeep() {
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
            toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun triggerVibration() {
        try {
            val context = getApplication<Application>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                vibrator?.vibrate(80)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // --- Backup & Restore ---
    fun exportLocalBackup(onResult: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val users = allUsers.value
            val drugs = allDrugs.value
            val companies = allCompanies.value
            val categories = allCategories.value
            val sales = allSalesBills.value
            val logs = allLogs.value
            val settings = listOf(
                SystemSetting("pharmacy_name", pharmacyName.value),
                SystemSetting("logo_index", logoIndex.value.toString())
            )

            val backupStr = BackupManager.exportBackup(users, drugs, companies, categories, sales, logs, settings)
            viewModelScope.launch(Dispatchers.Main) {
                onResult(backupStr)
            }
        }
    }

    fun importLocalBackup(backupJson: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val parsed = BackupManager.parseBackup(backupJson)

                // Restore users
                for (u in parsed.users) {
                    repository.insertUser(u)
                }
                // Restore drugs
                for (d in parsed.drugs) {
                    val existing = repository.getDrugByBarcode(d.barcode)
                    if (existing == null) {
                        repository.insertDrug(d)
                    } else {
                        repository.updateDrug(d.copy(id = existing.id))
                    }
                }
                // Restore companies
                for (c in parsed.companies) {
                    repository.insertCompany(c)
                }
                // Restore categories
                for (cat in parsed.categories) {
                    repository.insertCategory(cat)
                }
                // Restore sales
                for (s in parsed.sales) {
                    repository.insertSaleBill(s)
                }
                // Restore logs
                for (l in parsed.logs) {
                    repository.insertLog(l)
                }
                // Restore settings
                for (set in parsed.settings) {
                    repository.insertSetting(set)
                }

                viewModelScope.launch(Dispatchers.Main) {
                    _uiMessage.emit("تم استعادة النسخة الاحتياطية وتحديث قاعدة البيانات بالكامل بنجاح!")
                    onResult(true, "تم استيراد البيانات بنجاح.")
                }
            } catch (e: Exception) {
                viewModelScope.launch(Dispatchers.Main) {
                    _uiMessage.emit("خطأ أثناء استعادة النسخة الاحتياطية: ${e.message}")
                    onResult(false, "فشل الاستيراد: ${e.message}")
                }
            }
        }
    }

    // --- Helper for Hashing Passwords ---
    fun hashPassword(password: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(password.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
