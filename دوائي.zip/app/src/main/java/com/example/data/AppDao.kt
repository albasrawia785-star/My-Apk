package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // --- Users ---
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUser(username: String): User?

    @Query("SELECT * FROM users ORDER BY username ASC")
    fun getAllUsersFlow(): Flow<List<User>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Update
    suspend fun updateUser(user: User)

    @Delete
    suspend fun deleteUser(user: User)

    // --- Drugs ---
    @Query("SELECT * FROM drugs ORDER BY arabicName ASC")
    fun getAllDrugsFlow(): Flow<List<Drug>>

    @Query("SELECT * FROM drugs WHERE barcode = :barcode LIMIT 1")
    suspend fun getDrugByBarcode(barcode: String): Drug?

    @Query("SELECT * FROM drugs WHERE id = :id LIMIT 1")
    suspend fun getDrugById(id: Int): Drug?

    @Insert(onConflict = OnConflictStrategy.ABORT) // Abort if duplicate barcode index
    suspend fun insertDrug(drug: Drug)

    @Update
    suspend fun updateDrug(drug: Drug)

    @Delete
    suspend fun deleteDrug(drug: Drug)

    @Query("SELECT COUNT(*) FROM drugs")
    suspend fun getDrugsCount(): Int

    // --- Companies ---
    @Query("SELECT * FROM companies ORDER BY name ASC")
    fun getAllCompaniesFlow(): Flow<List<Company>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCompany(company: Company)

    @Update
    suspend fun updateCompany(company: Company)

    @Delete
    suspend fun deleteCompany(company: Company)

    // --- Categories ---
    @Query("SELECT * FROM categories ORDER BY name ASC")
    fun getAllCategoriesFlow(): Flow<List<Category>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCategory(category: Category)

    @Update
    suspend fun updateCategory(category: Category)

    @Delete
    suspend fun deleteCategory(category: Category)

    // --- Sale Bills ---
    @Query("SELECT * FROM sales_bills ORDER BY timestamp DESC")
    fun getAllSalesBillsFlow(): Flow<List<SaleBill>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSaleBill(saleBill: SaleBill)

    @Delete
    suspend fun deleteSaleBill(saleBill: SaleBill)

    // --- Operation Logs ---
    @Query("SELECT * FROM operation_logs ORDER BY timestamp DESC")
    fun getAllLogsFlow(): Flow<List<OperationLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: OperationLog)

    // --- System Settings ---
    @Query("SELECT * FROM system_settings WHERE `key` = :key LIMIT 1")
    suspend fun getSetting(key: String): SystemSetting?

    @Query("SELECT * FROM system_settings WHERE `key` = :key LIMIT 1")
    fun getSettingFlow(key: String): Flow<SystemSetting?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetting(setting: SystemSetting)
}
