package com.example.data

import org.json.JSONArray
import org.json.JSONObject

object BackupManager {
    fun exportBackup(
        users: List<User>,
        drugs: List<Drug>,
        companies: List<Company>,
        categories: List<Category>,
        sales: List<SaleBill>,
        logs: List<OperationLog>,
        settings: List<SystemSetting>
    ): String {
        val root = JSONObject()

        val usersArray = JSONArray()
        for (u in users) {
            val jo = JSONObject()
            jo.put("username", u.username)
            jo.put("passwordHash", u.passwordHash)
            jo.put("role", u.role)
            jo.put("canAddDrug", u.canAddDrug)
            jo.put("canEditDrug", u.canEditDrug)
            jo.put("canDeleteDrug", u.canDeleteDrug)
            jo.put("canDeleteSale", u.canDeleteSale)
            jo.put("mustChangePassword", u.mustChangePassword)
            usersArray.put(jo)
        }
        root.put("users", usersArray)

        val drugsArray = JSONArray()
        for (d in drugs) {
            val jo = JSONObject()
            jo.put("arabicName", d.arabicName)
            jo.put("scientificName", d.scientificName)
            jo.put("companyName", d.companyName)
            jo.put("categoryName", d.categoryName)
            jo.put("strength", d.strength)
            jo.put("dosageForm", d.dosageForm)
            jo.put("batchNumber", d.batchNumber)
            jo.put("productionDate", d.productionDate)
            jo.put("expiryDate", d.expiryDate)
            jo.put("purchasePrice", d.purchasePrice)
            jo.put("salePrice", d.salePrice)
            jo.put("quantity", d.quantity)
            jo.put("minLimit", d.minLimit)
            jo.put("barcode", d.barcode)
            jo.put("notes", d.notes)
            jo.put("isArchived", d.isArchived)
            drugsArray.put(jo)
        }
        root.put("drugs", drugsArray)

        val companiesArray = JSONArray()
        for (c in companies) {
            val jo = JSONObject()
            jo.put("name", c.name)
            jo.put("details", c.details)
            companiesArray.put(jo)
        }
        root.put("companies", companiesArray)

        val categoriesArray = JSONArray()
        for (c in categories) {
            val jo = JSONObject()
            jo.put("name", c.name)
            categoriesArray.put(jo)
        }
        root.put("categories", categoriesArray)

        val salesArray = JSONArray()
        for (s in sales) {
            val jo = JSONObject()
            jo.put("invoiceNumber", s.invoiceNumber)
            jo.put("timestamp", s.timestamp)
            jo.put("drugId", s.drugId)
            jo.put("drugName", s.drugName)
            jo.put("quantity", s.quantity)
            jo.put("unitPrice", s.unitPrice)
            jo.put("totalPrice", s.totalPrice)
            jo.put("username", s.username)
            salesArray.put(jo)
        }
        root.put("sales", salesArray)

        val logsArray = JSONArray()
        for (l in logs) {
            val jo = JSONObject()
            jo.put("username", l.username)
            jo.put("timestamp", l.timestamp)
            jo.put("barcode", l.barcode)
            jo.put("drugName", l.drugName)
            jo.put("operationType", l.operationType)
            jo.put("details", l.details)
            logsArray.put(jo)
        }
        root.put("logs", logsArray)

        val settingsArray = JSONArray()
        for (s in settings) {
            val jo = JSONObject()
            jo.put("key", s.key)
            jo.put("value", s.value)
            settingsArray.put(jo)
        }
        root.put("settings", settingsArray)

        return root.toString(4)
    }

    fun parseBackup(jsonStr: String): ParsedBackup {
        val root = JSONObject(jsonStr)
        val users = mutableListOf<User>()
        val drugs = mutableListOf<Drug>()
        val companies = mutableListOf<Company>()
        val categories = mutableListOf<Category>()
        val sales = mutableListOf<SaleBill>()
        val logs = mutableListOf<OperationLog>()
        val settings = mutableListOf<SystemSetting>()

        val usersArray = root.optJSONArray("users")
        if (usersArray != null) {
            for (i in 0 until usersArray.length()) {
                val jo = usersArray.getJSONObject(i)
                users.add(
                    User(
                        username = jo.getString("username"),
                        passwordHash = jo.getString("passwordHash"),
                        role = jo.getString("role"),
                        canAddDrug = jo.optBoolean("canAddDrug", true),
                        canEditDrug = jo.optBoolean("canEditDrug", true),
                        canDeleteDrug = jo.optBoolean("canDeleteDrug", true),
                        canDeleteSale = jo.optBoolean("canDeleteSale", true),
                        mustChangePassword = jo.optBoolean("mustChangePassword", false)
                    )
                )
            }
        }

        val drugsArray = root.optJSONArray("drugs")
        if (drugsArray != null) {
            for (i in 0 until drugsArray.length()) {
                val jo = drugsArray.getJSONObject(i)
                drugs.add(
                    Drug(
                        arabicName = jo.getString("arabicName"),
                        scientificName = jo.getString("scientificName"),
                        companyName = jo.getString("companyName"),
                        categoryName = jo.getString("categoryName"),
                        strength = jo.getString("strength"),
                        dosageForm = jo.getString("dosageForm"),
                        batchNumber = jo.getString("batchNumber"),
                        productionDate = jo.getString("productionDate"),
                        expiryDate = jo.getString("expiryDate"),
                        purchasePrice = jo.getDouble("purchasePrice"),
                        salePrice = jo.getDouble("salePrice"),
                        quantity = jo.getInt("quantity"),
                        minLimit = jo.getInt("minLimit"),
                        barcode = jo.getString("barcode"),
                        notes = jo.optString("notes", ""),
                        isArchived = jo.optBoolean("isArchived", false)
                    )
                )
            }
        }

        val companiesArray = root.optJSONArray("companies")
        if (companiesArray != null) {
            for (i in 0 until companiesArray.length()) {
                val jo = companiesArray.getJSONObject(i)
                companies.add(
                    Company(
                        name = jo.getString("name"),
                        details = jo.optString("details", "")
                    )
                )
            }
        }

        val categoriesArray = root.optJSONArray("categories")
        if (categoriesArray != null) {
            for (i in 0 until categoriesArray.length()) {
                val jo = categoriesArray.getJSONObject(i)
                categories.add(
                    Category(
                        name = jo.getString("name")
                    )
                )
            }
        }

        val salesArray = root.optJSONArray("sales")
        if (salesArray != null) {
            for (i in 0 until salesArray.length()) {
                val jo = salesArray.getJSONObject(i)
                sales.add(
                    SaleBill(
                        invoiceNumber = jo.getString("invoiceNumber"),
                        timestamp = jo.optLong("timestamp", System.currentTimeMillis()),
                        drugId = jo.optInt("drugId", 0),
                        drugName = jo.getString("drugName"),
                        quantity = jo.getInt("quantity"),
                        unitPrice = jo.getDouble("unitPrice"),
                        totalPrice = jo.getDouble("totalPrice"),
                        username = jo.getString("username")
                    )
                )
            }
        }

        val logsArray = root.optJSONArray("logs")
        if (logsArray != null) {
            for (i in 0 until logsArray.length()) {
                val jo = logsArray.getJSONObject(i)
                logs.add(
                    OperationLog(
                        username = jo.getString("username"),
                        timestamp = jo.optLong("timestamp", System.currentTimeMillis()),
                        barcode = jo.optString("barcode", ""),
                        drugName = jo.optString("drugName", ""),
                        operationType = jo.getString("operationType"),
                        details = jo.optString("details", "")
                    )
                )
            }
        }

        val settingsArray = root.optJSONArray("settings")
        if (settingsArray != null) {
            for (i in 0 until settingsArray.length()) {
                val jo = settingsArray.getJSONObject(i)
                settings.add(
                    SystemSetting(
                        key = jo.getString("key"),
                        value = jo.getString("value")
                    )
                )
            }
        }

        return ParsedBackup(users, drugs, companies, categories, sales, logs, settings)
    }

    data class ParsedBackup(
        val users: List<User>,
        val drugs: List<Drug>,
        val companies: List<Company>,
        val categories: List<Category>,
        val sales: List<SaleBill>,
        val logs: List<OperationLog>,
        val settings: List<SystemSetting>
    )
}
