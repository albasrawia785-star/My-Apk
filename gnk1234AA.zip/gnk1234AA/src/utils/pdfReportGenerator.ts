import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { getUserBranchDisplayName, getUserDisplayName } from './userUtils';
import { formatNumber } from './formatters';
import { Debtor, Supplier, InstallmentRecord, User, DebtorTransaction } from '../types';
import { escapeHtml } from './sanitize';
import { getLocalDebtorHistory } from '../services/turso';

interface PrintReportHeaderOptions {
  title: string;
  subtitle: string;
  branchName: string;
  userName: string;
  periodLabel?: string;
  statsSummaryHtml?: string;
  accentColor?: string; // 'blue' | 'rose' | 'emerald' | 'amber' | 'purple'
  companyName?: string;
  companyPhone?: string;
  companyAddress?: string;
}

/**
 * Retrieve active session user safely from localStorage
 */
function getActiveSessionUser(): User | null {
  try {
    const raw = localStorage.getItem('session_user');
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

/**
 * Retrieve user settings safely from localStorage
 */
function getActiveUserSettings(userId?: number): any {
  try {
    const uId = userId || getActiveSessionUser()?.id;
    if (!uId) return null;
    const raw = localStorage.getItem(`app_settings_user_${uId}`);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

/**
 * Resolves full, un-truncated transactions history for a Debtor
 * Merging debtor.history and local storage historyMap so no transactions are missed.
 */
function resolveCompleteDebtorHistory(debtor: Debtor, userId?: number): DebtorTransaction[] {
  const uId = userId || debtor.userId || getActiveSessionUser()?.id || 0;
  const historyMap = uId ? getLocalDebtorHistory(uId) : {};
  const fromMap = (historyMap && historyMap[debtor.id]) ? historyMap[debtor.id] : [];
  const fromDebtor = Array.isArray(debtor.history) ? debtor.history : [];

  const map = new Map<string, DebtorTransaction>();

  // Add all transactions from both sources
  [...fromDebtor, ...fromMap].forEach((tx) => {
    if (!tx || typeof tx !== 'object') return;
    const key = tx.id ? String(tx.id) : `${tx.date}_${tx.amount}_${tx.type}_${tx.notes || tx.description || ''}`;
    if (!map.has(key)) {
      map.set(key, tx);
    }
  });

  let combined = Array.from(map.values());

  // Fallback: If no recorded transactions exist but debtor has a balance or creation date, generate opening record
  if (combined.length === 0 && (Number(debtor.amount) > 0 || debtor.createdAt)) {
    combined = [
      {
        id: `initial-${debtor.id}`,
        debtorId: debtor.id,
        type: 'initial',
        amount: Number(debtor.amount) || 0,
        balanceAfter: Number(debtor.amount) || 0,
        date: debtor.createdAt || new Date().toISOString(),
        description: 'فتح حساب وتسجيل الرصيد الأولي',
      },
    ];
  }

  return combined.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}

function createPdfProgressBarUI(reportTitle: string) {
  const existing = document.getElementById('pdf-generation-loading-overlay');
  if (existing) existing.remove();

  const overlay = document.createElement('div');
  overlay.id = 'pdf-generation-loading-overlay';
  overlay.style.position = 'fixed';
  overlay.style.inset = '0';
  overlay.style.backgroundColor = 'rgba(15, 23, 42, 0.7)';
  overlay.style.backdropFilter = 'blur(6px)';
  (overlay.style as any).webkitBackdropFilter = 'blur(6px)';
  overlay.style.zIndex = '999999';
  overlay.style.display = 'flex';
  overlay.style.alignItems = 'center';
  overlay.style.justifyContent = 'center';
  overlay.style.padding = '16px';
  overlay.style.direction = 'rtl';
  overlay.style.fontFamily = "system-ui, -apple-system, 'Segoe UI', Roboto, 'Cairo', 'Arial', sans-serif";

  const displayTitle = reportTitle.length > 34 ? `${reportTitle.slice(0, 34)}...` : reportTitle;

  overlay.innerHTML = `
    <div style="
      background: #ffffff;
      border-radius: 24px;
      padding: 24px 20px;
      width: 100%;
      max-width: 420px;
      box-shadow: 0 25px 50px -12px rgba(0,0,0,0.35);
      border: 1px solid #e2e8f0;
      text-align: right;
      animation: pdfPopIn 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    ">
      <style>
        @keyframes pdfPopIn {
          from { opacity: 0; transform: scale(0.92) translateY(12px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }
      </style>
      
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
        <div style="display: flex; align-items: center; gap: 10px;">
          <div style="
            width: 42px;
            height: 42px;
            border-radius: 16px;
            background: linear-gradient(135deg, #eff6ff, #dbeafe);
            color: #2563eb;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 19px;
            box-shadow: 0 4px 12px rgba(37,99,235,0.15);
            border: 1px solid #bfdbfe;
          ">
            <i class="fa-solid fa-file-pdf"></i>
          </div>
          <div>
            <div style="font-size: 13.5px; font-weight: 800; color: #0f172a; line-height: 1.2;">جاري إصدار تقرير الـ PDF</div>
            <div style="font-size: 11px; color: #64748b; margin-top: 2px;" id="pdf-report-subtitle">${displayTitle}</div>
          </div>
        </div>
        <div id="pdf-percent-badge" style="
          font-size: 12.5px;
          font-weight: 900;
          font-family: monospace;
          color: #2563eb;
          background: #eff6ff;
          padding: 4px 12px;
          border-radius: 12px;
          border: 1px solid #bfdbfe;
        ">0%</div>
      </div>

      <!-- Progress Bar Track -->
      <div style="
        width: 100%;
        height: 10px;
        background: #f1f5f9;
        border-radius: 999px;
        overflow: hidden;
        margin: 14px 0 10px 0;
        position: relative;
        border: 1px solid #e2e8f0;
      ">
        <div id="pdf-progress-bar-fill" style="
          width: 0%;
          height: 100%;
          background: linear-gradient(90deg, #2563eb, #4f46e5, #059669);
          border-radius: 999px;
          transition: width 0.35s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 0 0 10px rgba(37,99,235,0.5);
        "></div>
      </div>

      <div style="display: flex; align-items: center; justify-content: space-between; font-size: 11px; color: #64748b;">
        <span id="pdf-progress-status-text" style="font-weight: 700; color: #334155;">جاري تجهيز محتوى المستند والجداول...</span>
        <span style="display: flex; align-items: center; gap: 4px;">
          <i class="fa-solid fa-circle-notch fa-spin" style="color: #2563eb;"></i>
        </span>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
}

function updatePdfProgressBar(percent: number, statusText: string) {
  const badge = document.getElementById('pdf-percent-badge');
  const fill = document.getElementById('pdf-progress-bar-fill');
  const text = document.getElementById('pdf-progress-status-text');

  if (badge) badge.innerText = `${percent}%`;
  if (fill) fill.style.width = `${percent}%`;
  if (text) text.innerText = statusText;
}

function removePdfProgressBarUI() {
  const overlay = document.getElementById('pdf-generation-loading-overlay');
  if (overlay) {
    updatePdfProgressBar(100, 'تم إكمال ملف الـ PDF بنجاح!');
    setTimeout(() => {
      if (document.body.contains(overlay)) {
        document.body.removeChild(overlay);
      }
    }, 450);
  }
}

/**
 * Generates an ultra-crisp, high-definition PDF with zero cut text across pages,
 * smart pagination without splitting table rows or cards midway, and crystal clear Arabic typography.
 */
export async function printSystemPdfReport(
  options: PrintReportHeaderOptions,
  tableSectionsHtml: string
) {
  const { title, subtitle, branchName, userName, periodLabel, statsSummaryHtml, accentColor = 'blue' } = options;

  let compName = options.companyName;
  let compPhone = options.companyPhone;
  let compAddr = options.companyAddress;

  if (!compName) {
    const s = getActiveUserSettings();
    if (s) {
      if (s.companyName) compName = s.companyName;
      if (s.companyPhone) compPhone = s.companyPhone;
      if (s.companyAddress) compAddr = s.companyAddress;
    }
  }

  const finalCompanyName = compName || 'نظام إدارة الحسابات المالية';

  createPdfProgressBarUI(title);
  updatePdfProgressBar(10, 'جاري تجهيز بيانات كشف الحساب وتنسيق الجداول...');

  let headerGradient = 'linear-gradient(135deg, #1e293b, #0f172a)';
  let primaryColor = '#1e3a8a';

  if (accentColor === 'rose') {
    headerGradient = 'linear-gradient(135deg, #881337, #4c0519)';
    primaryColor = '#881337';
  } else if (accentColor === 'emerald') {
    headerGradient = 'linear-gradient(135deg, #064e3b, #022c22)';
    primaryColor = '#064e3b';
  } else if (accentColor === 'amber') {
    headerGradient = 'linear-gradient(135deg, #78350f, #451a03)';
    primaryColor = '#78350f';
  } else if (accentColor === 'purple') {
    headerGradient = 'linear-gradient(135deg, #581c87, #3b0764)';
    primaryColor = '#3b0764';
  }

  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const dateStr = `${year}/${month}/${day}`;

  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const timeStr = `${hours}:${minutes}`;

  const cleanTitle = (title || 'تقرير_كشف_الحساب').trim().replace(/[\s/\\:*?"<>|]+/g, '_');
  const dateFile = dateStr.replace(/\//g, '-');
  const pdfFileName = `${cleanTitle}-${dateFile}.pdf`;

  // Build offscreen container for pixel-perfect rendering
  const container = document.createElement('div');
  container.style.position = 'absolute';
  container.style.top = '0';
  container.style.left = '0';
  container.style.width = '740px'; // Optimal width matching standard A4 printable aspect ratio
  container.style.backgroundColor = '#ffffff';
  container.style.color = '#0f172a';
  container.style.fontFamily = "'Cairo', system-ui, -apple-system, 'Segoe UI', Roboto, 'Arial', sans-serif";
  container.style.direction = 'rtl';
  container.style.padding = '18px 20px';
  container.style.boxSizing = 'border-box';
  container.style.zIndex = '-9999';
  container.style.opacity = '1';
  container.style.visibility = 'visible';
  container.style.pointerEvents = 'none';

  container.innerHTML = `
    <style>
      .pdf-container * {
        box-sizing: border-box;
        font-family: 'Cairo', system-ui, -apple-system, 'Segoe UI', Roboto, 'Arial', sans-serif;
        letter-spacing: 0 !important;
        word-spacing: normal !important;
        -webkit-font-smoothing: antialiased;
        text-rendering: geometricPrecision;
      }
      .pdf-report-header {
        background: ${headerGradient};
        color: #ffffff;
        padding: 16px 20px;
        border-radius: 12px;
        margin-bottom: 12px;
        text-align: right;
        break-inside: avoid;
        page-break-inside: avoid;
      }
      .pdf-title {
        font-size: 13.5pt;
        font-weight: 800;
        margin: 0 0 4px 0;
        color: #ffffff;
        line-height: 1.35;
      }
      .pdf-subtitle {
        font-size: 8.5pt;
        opacity: 0.92;
        margin: 0;
        color: #f1f5f9;
        line-height: 1.4;
      }
      .pdf-stats-grid {
        margin-bottom: 12px;
        break-inside: avoid;
        page-break-inside: avoid;
      }
      .person-card {
        background: #ffffff;
        border: 1.5px solid #cbd5e1;
        border-radius: 10px;
        margin-bottom: 12px;
        overflow: hidden;
        break-inside: avoid;
        page-break-inside: avoid;
      }
      .person-card-header {
        background: #f8fafc;
        padding: 10px 14px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1.5px solid #e2e8f0;
      }
      .person-name {
        font-size: 11pt;
        font-weight: 800;
        color: #0f172a;
        line-height: 1.3;
      }
      .person-phone {
        font-size: 8pt;
        color: #64748b;
        margin-top: 3px;
        line-height: 1.3;
      }
      .person-amount-box {
        text-align: left;
      }
      .amount-value {
        font-size: 11.5pt;
        font-weight: 800;
        color: ${primaryColor};
        display: block;
        line-height: 1.2;
      }
      .amount-label {
        font-size: 7.5pt;
        color: #64748b;
        margin-top: 2px;
      }
      .tx-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 8pt;
        margin-top: 0;
        table-layout: auto;
      }
      .tx-table th, .tx-table td {
        word-wrap: break-word !important;
        word-break: break-word !important;
        overflow-wrap: break-word !important;
        white-space: normal !important;
        vertical-align: middle;
        line-height: 1.45;
      }
      .tx-table th {
        background-color: #f1f5f9;
        color: #334155;
        padding: 8px 10px;
        text-align: right;
        font-weight: 800;
        border-bottom: 1.5px solid #cbd5e1;
      }
      .tx-table td {
        padding: 8px 10px;
        border-bottom: 1px solid #f1f5f9;
        color: #1e293b;
        text-align: right;
      }
      .tx-table tr {
        break-inside: avoid;
        page-break-inside: avoid;
      }
      .tx-table tr:nth-child(even) td {
        background-color: #fafcff;
      }
      .tx-type-pay {
        color: #047857;
        font-weight: 800;
        background: #ecfdf5;
        border: 1px solid #a7f3d0;
        padding: 2px 7px;
        border-radius: 5px;
        display: inline-block;
        font-size: 7.5pt;
      }
      .tx-type-add {
        color: #be123c;
        font-weight: 800;
        background: #fff1f2;
        border: 1px solid #fecdd3;
        padding: 2px 7px;
        border-radius: 5px;
        display: inline-block;
        font-size: 7.5pt;
      }
      .tx-type-info {
        color: #0369a1;
        font-weight: 800;
        background: #f0f9ff;
        border: 1px solid #bae6fd;
        padding: 2px 7px;
        border-radius: 5px;
        display: inline-block;
        font-size: 7.5pt;
      }
      .pdf-footer {
        margin-top: 14px;
        padding-top: 8px;
        border-top: 1px solid #e2e8f0;
        font-size: 7.5pt;
        color: #64748b;
        display: flex;
        justify-content: space-between;
        break-inside: avoid;
        page-break-inside: avoid;
      }
    </style>

    <div class="pdf-container">
      <div class="pdf-report-header">
        <!-- 1. Store / Company Name prominently at top -->
        <div style="font-size: 15pt; font-weight: 900; color: #ffffff; margin-bottom: 8px; line-height: 1.3;">
          ${escapeHtml(finalCompanyName)}
        </div>
        
        <!-- 2. Phone & Address of Business -->
        ${(compPhone || compAddr) ? `
          <div style="font-size: 8.5pt; font-weight: 600; color: #f1f5f9; display: flex; align-items: center; gap: 14px; margin-bottom: 10px; line-height: 1.4;">
            ${compPhone ? `<span>الهاتف: <strong style="font-family: monospace; font-size: 9pt;">${escapeHtml(compPhone)}</strong></span>` : ''}
            ${compAddr ? `<span>العنوان: ${escapeHtml(compAddr)}</span>` : ''}
          </div>
        ` : ''}

        <!-- 3. Report Title & Subtitle -->
        <div style="display: inline-block; background: rgba(255, 255, 255, 0.22); padding: 4px 10px; border-radius: 6px; font-size: 9.5pt; font-weight: 800; color: #ffffff; margin-top: 2px;">
          ${escapeHtml(title)}
        </div>
        ${subtitle ? `<p class="pdf-subtitle" style="margin-top: 4px;">${escapeHtml(subtitle)}</p>` : ''}
        ${periodLabel ? `<p class="pdf-subtitle" style="margin-top: 3px; font-weight: 700; color: #fde047;">فترة التقرير: ${escapeHtml(periodLabel)}</p>` : ''}
      </div>

      ${statsSummaryHtml ? `<div class="pdf-stats-grid">${statsSummaryHtml}</div>` : ''}

      <div class="pdf-content">
        ${tableSectionsHtml}
      </div>

      <div class="pdf-footer">
        <div>تم التصدير آلياً بواسطة نظام إدارة الديون للحسابات • ${escapeHtml(finalCompanyName)}</div>
        <div>تاريخ الإصدار: ${dateStr} ${timeStr}</div>
      </div>
    </div>
  `;

  document.body.appendChild(container);

  try {
    updatePdfProgressBar(30, 'جاري ضبط الخطوط العربية وتنسيق الفواصل الذكية...');
    
    // Ensure all custom fonts are ready before rasterizing
    if ((document as any).fonts && (document as any).fonts.ready) {
      await (document as any).fonts.ready;
    }
    await new Promise((resolve) => setTimeout(resolve, 100));

    // Render with scale 2.0 for crystal clear high-resolution graphics
    const canvas = await html2canvas(container, {
      scale: 2.0,
      useCORS: true,
      allowTaint: false,
      logging: false,
      backgroundColor: '#ffffff',
      scrollX: 0,
      scrollY: 0,
      windowWidth: 740,
      x: 0,
      y: 0,
      width: container.offsetWidth || 740,
      height: container.offsetHeight,
    });

    if (!canvas || canvas.width === 0 || canvas.height === 0) {
      throw new Error('Canvas rendering produced empty image');
    }

    updatePdfProgressBar(65, 'جاري تطبيق الفواصل الذكية لمنع تقطيع السطور والجداول...');
    await new Promise((resolve) => setTimeout(resolve, 50));

    // Calculate element safe break points based on container DOM elements
    const containerRect = container.getBoundingClientRect();
    const scaleFactor = canvas.height / containerRect.height;

    // Collect all major item blocks (.person-card, .pdf-report-header, .pdf-stats-grid, .pdf-footer)
    // and individual table rows (.tx-table tbody tr)
    const blockElements = Array.from(
      container.querySelectorAll('.pdf-report-header, .pdf-stats-grid, .person-card, .pdf-footer')
    );

    interface BlockBox {
      top: number;
      bottom: number;
      element: Element;
    }

    const blocks: BlockBox[] = blockElements.map((el) => {
      const rect = el.getBoundingClientRect();
      return {
        top: Math.max(0, (rect.top - containerRect.top) * scaleFactor),
        bottom: Math.min(canvas.height, (rect.bottom - containerRect.top) * scaleFactor),
        element: el,
      };
    }).sort((a, b) => a.top - b.top);

    // Also collect all individual table rows for fine-grained breaking when a single card is very tall
    const trElements = Array.from(container.querySelectorAll('.tx-table tbody tr'));
    const trBoxes: BlockBox[] = trElements.map((el) => {
      const rect = el.getBoundingClientRect();
      return {
        top: Math.max(0, (rect.top - containerRect.top) * scaleFactor),
        bottom: Math.min(canvas.height, (rect.bottom - containerRect.top) * scaleFactor),
        element: el,
      };
    }).sort((a, b) => a.top - b.top);

    // Page layout parameters in mm
    const pageWidthMm = 210; // A4 Width
    const pageHeightMm = 297; // A4 Height
    const topMarginMm = 8;
    const bottomMarginMm = 10;
    const usableHeightMm = pageHeightMm - topMarginMm - bottomMarginMm; // 279mm

    // Conversion: 1mm on PDF = (canvas.width / 210) px on canvas
    const pxPerMm = canvas.width / pageWidthMm;
    const maxPageCanvasHeightPx = usableHeightMm * pxPerMm;

    // Calculate smart slice boundaries so NO card or row is ever sliced horizontally
    const pageSlices: { startY: number; endY: number }[] = [];
    let currentY = 0;

    while (currentY < canvas.height - 2) {
      const targetMaxY = currentY + maxPageCanvasHeightPx;

      if (targetMaxY >= canvas.height) {
        pageSlices.push({ startY: currentY, endY: canvas.height });
        break;
      }

      // Check if any major block straddles targetMaxY
      const overflowingBlock = blocks.find((b) => b.top < targetMaxY && b.bottom > targetMaxY);

      let chosenEndY = targetMaxY;

      if (overflowingBlock) {
        // If the overflowing block starts comfortably after currentY, cut right before it!
        if (overflowingBlock.top > currentY + maxPageCanvasHeightPx * 0.25) {
          chosenEndY = overflowingBlock.top;
        } else {
          // The block itself is very tall (e.g. large table inside). Check table rows inside it:
          const overflowingTr = trBoxes.find((tr) => tr.top < targetMaxY && tr.bottom > targetMaxY);
          if (overflowingTr && overflowingTr.top > currentY + maxPageCanvasHeightPx * 0.25) {
            chosenEndY = overflowingTr.top;
          } else {
            // Find the last tr that fits entirely
            const fittingTrs = trBoxes.filter((tr) => tr.top >= currentY && tr.bottom <= targetMaxY);
            if (fittingTrs.length > 0) {
              chosenEndY = fittingTrs[fittingTrs.length - 1].bottom;
            }
          }
        }
      } else {
        // Find the last block that fits entirely within this page
        const fittingBlocks = blocks.filter((b) => b.top >= currentY && b.bottom <= targetMaxY);
        if (fittingBlocks.length > 0) {
          chosenEndY = fittingBlocks[fittingBlocks.length - 1].bottom;
        }
      }

      // Safeguard against zero or reverse progress
      if (chosenEndY <= currentY) {
        chosenEndY = targetMaxY;
      }

      pageSlices.push({ startY: currentY, endY: chosenEndY });
      currentY = chosenEndY;
    }

    updatePdfProgressBar(85, 'جاري بناء صفحات المستند النهائية...');
    await new Promise((resolve) => setTimeout(resolve, 50));

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    const totalPages = pageSlices.length;

    for (let i = 0; i < totalPages; i++) {
      if (i > 0) {
        pdf.addPage();
      }

      const slice = pageSlices[i];
      const sliceHeightPx = slice.endY - slice.startY;

      // Crop the slice from the main canvas onto an offscreen canvas
      const pageCanvas = document.createElement('canvas');
      pageCanvas.width = canvas.width;
      pageCanvas.height = sliceHeightPx;

      const ctx = pageCanvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
        ctx.drawImage(
          canvas,
          0,
          slice.startY,
          canvas.width,
          sliceHeightPx,
          0,
          0,
          pageCanvas.width,
          sliceHeightPx
        );
      }

      const sliceImgData = pageCanvas.toDataURL('image/jpeg', 0.93);
      const sliceHeightMm = (sliceHeightPx * pageWidthMm) / canvas.width;

      // Add image cleanly within margins
      pdf.addImage(sliceImgData, 'JPEG', 0, topMarginMm, pageWidthMm, sliceHeightMm, undefined, 'FAST');

      // Add clean, un-corrupted page numbering for multi-page documents
      if (totalPages > 1) {
        pdf.setFont('helvetica', 'normal');
        pdf.setFontSize(8);
        pdf.setTextColor(148, 163, 184);
        pdf.text(`${i + 1} / ${totalPages}`, pageWidthMm / 2, pageHeightMm - 4, { align: 'center' });
      }
    }

    updatePdfProgressBar(95, 'جاري إتمام الحفظ والمشاركة...');
    await new Promise((resolve) => setTimeout(resolve, 50));

    const pdfBlob = pdf.output('blob');
    const pdfFile = new File([pdfBlob], pdfFileName, { type: 'application/pdf' });

    // 1. Check if running inside Capacitor Android APK
    const win = window as any;
    if (win.Capacitor && win.Capacitor.Plugins) {
      try {
        const { Filesystem, Share } = win.Capacitor.Plugins;
        const base64Data = pdf.output('datauristring').split(',')[1];

        if (Filesystem) {
          const savedFile = await Filesystem.writeFile({
            path: pdfFileName,
            data: base64Data,
            directory: 'CACHE',
          });

          if (Share && savedFile && savedFile.uri) {
            await Share.share({
              title: title,
              text: `${title} - ${branchName}`,
              url: savedFile.uri,
              dialogTitle: 'حفظ أو مشاركة تقرير PDF',
            });
            return;
          }
        }
      } catch (capErr) {
        console.warn('Capacitor native PDF share fallback:', capErr);
      }
    }

    // 2. Try Native Share API (Mobile Web / WhatsApp / Telegram)
    let sharedSuccessfully = false;
    if (navigator.canShare && navigator.canShare({ files: [pdfFile] })) {
      try {
        await navigator.share({
          files: [pdfFile],
          title: title,
          text: `${title} - ${branchName}`,
        });
        sharedSuccessfully = true;
      } catch (shareErr: any) {
        if (shareErr && shareErr.name === 'AbortError') {
          sharedSuccessfully = true; // User intentionally dismissed share sheet
        }
      }
    }

    // 3. Direct File Download fallback for desktop browsers
    if (!sharedSuccessfully) {
      pdf.save(pdfFileName);
    }
  } catch (err) {
    console.error('PDF Generation Error:', err);
    window.print();
  } finally {
    removePdfProgressBarUI();
    if (document.body.contains(container)) {
      document.body.removeChild(container);
    }
  }
}

/**
 * Export Single Debtor PDF Statement (كشف حساب مدين / دائن مفصل وكامل)
 */
export function exportSingleDebtorPdf(
  debtor: Debtor,
  currentUser?: User | null,
  storeName?: string,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const activeUser = currentUser || getActiveSessionUser();
  const branchName = activeUser ? getUserBranchDisplayName(activeUser) : (storeName || 'الفرع الرئيسي');
  const userName = activeUser ? getUserDisplayName(activeUser) : 'مدير النظام';

  const userSettings = getActiveUserSettings(activeUser?.id);
  const finalNumberFormat = numberFormat || userSettings?.numberFormat || 'english';

  const isCreditor = debtor.type === 'creditor';
  const reportTitle = isCreditor ? `كشف حساب دائن (التزام مالي) - ${debtor.name}` : `كشف حساب زبون (مدين) - ${debtor.name}`;
  const accentColor = isCreditor ? 'rose' : 'blue';

  const cleanCreatedAt = debtor.createdAt ? debtor.createdAt.split('T')[0].replace(/-/g, '/') : '-';

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 12px;">
    <div style="background: ${isCreditor ? '#fff1f2' : '#eff6ff'}; border: 1.5px solid ${isCreditor ? '#fecdd3' : '#bfdbfe'}; padding: 10px 14px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: ${isCreditor ? '#881337' : '#1e3a8a'}; font-weight: 700;">الرصيد المالي القائم</span>
      <div style="font-size: 12.5pt; font-weight: 800; color: ${isCreditor ? '#be123c' : '#1d4ed8'}; margin-top: 2px;">${formatNumber(debtor.amount, finalNumberFormat)} د.ع</div>
    </div>
    <div style="background: #f8fafc; border: 1.5px solid #e2e8f0; padding: 10px 14px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #475569; font-weight: 700;">تاريخ فتح الحساب والتسجيل</span>
      <div style="font-size: 11pt; font-weight: 700; color: #334155; margin-top: 2px;">${cleanCreatedAt}</div>
    </div>
  </div>`;

  // Merge debtor.history and historyMap to ensure 100% of recorded transactions appear
  const sortedHistory = resolveCompleteDebtorHistory(debtor, activeUser?.id);

  let txRows = '';
  if (sortedHistory.length === 0) {
    txRows = `<tr><td colspan="5" style="text-align:center; color:#64748b; padding:14px; font-weight: 700;">لا توجد حركات تسديد أو إضافة مسجلة لهذا الحساب</td></tr>`;
  } else {
    sortedHistory.forEach((tx, idx) => {
      const isPay = tx.type === 'pay';
      const isInitial = tx.type === 'initial';
      const typeLabel = isPay ? 'تسديد دفعة' : isInitial ? 'رصيد افتتاحي' : (isCreditor ? 'دين عليّ إضافي' : 'دين جديد');
      const typeClass = isPay ? 'tx-type-pay' : isInitial ? 'tx-type-info' : 'tx-type-add';
      const amountPrefix = isPay ? '-' : '+';
      const cleanDate = tx.date ? tx.date.split('T')[0].replace(/-/g, '/') : '-';

      txRows += `<tr>
        <td style="width: 6%; text-align: center;"><strong>${formatNumber(idx + 1, finalNumberFormat)}</strong></td>
        <td style="width: 18%;"><span class="${typeClass}">${typeLabel}</span></td>
        <td style="width: 22%;"><strong>${amountPrefix}${formatNumber(tx.amount, finalNumberFormat)} د.ع</strong></td>
        <td style="width: 18%;">${cleanDate}</td>
        <td style="width: 36%;">${escapeHtml(tx.notes || tx.description || '-')}</td>
      </tr>`;
    });
  }

  const rawPhone = debtor.phone ? debtor.phone.trim() : '';
  const cleanPhone = rawPhone && rawPhone !== 'غير مسجل' ? rawPhone : '';

  const htmlSection = `<div class="person-card">
    <div class="person-card-header">
      <div>
        <div class="person-name">${escapeHtml(debtor.name)}</div>
        <div class="person-phone">${cleanPhone ? `رقم الهاتف: <span style="font-family: monospace; font-size: 8.5pt;">${escapeHtml(cleanPhone)}</span> | ` : ''}تاريخ التسجيل: ${cleanCreatedAt}</div>
      </div>
      <div class="person-amount-box">
        <span class="amount-value">${formatNumber(debtor.amount, finalNumberFormat)} د.ع</span>
        <span class="amount-label">الرصيد القائم</span>
      </div>
    </div>
    <div style="padding: 6px 10px; background: #fff;">
      <table class="tx-table">
        <thead>
          <tr>
            <th style="width: 6%; text-align: center;">#</th>
            <th style="width: 18%;">نوع الحركة</th>
            <th style="width: 22%;">المبلغ</th>
            <th style="width: 18%;">التاريخ</th>
            <th style="width: 36%;">الملاحظات والتفاصيل</th>
          </tr>
        </thead>
        <tbody>
          ${txRows}
        </tbody>
      </table>
    </div>
  </div>`;

  printSystemPdfReport(
    {
      title: reportTitle,
      subtitle: cleanPhone ? `رقم الهاتف: ${cleanPhone}` : '',
      branchName,
      userName,
      statsSummaryHtml,
      accentColor,
    },
    htmlSection
  );
}

/**
 * Export Single Supplier PDF Statement
 */
export function exportSingleSupplierPdf(
  supplier: Supplier,
  currentUser?: User | null,
  storeName?: string,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const activeUser = currentUser || getActiveSessionUser();
  const branchName = activeUser ? getUserBranchDisplayName(activeUser) : (storeName || 'الفرع الرئيسي');
  const userName = activeUser ? getUserDisplayName(activeUser) : 'مدير النظام';

  const userSettings = getActiveUserSettings(activeUser?.id);
  const finalNumberFormat = numberFormat || userSettings?.numberFormat || 'english';

  const cleanCreatedAt = supplier.createdAt ? supplier.createdAt.split('T')[0].replace(/-/g, '/') : '-';
  const rawSupPhone = supplier.phone ? supplier.phone.trim() : '';
  const cleanPhone = rawSupPhone && rawSupPhone !== 'غير مسجل' ? rawSupPhone : '';

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 12px;">
    <div style="background: #fffbe3; border: 1.5px solid #fef08a; padding: 10px 14px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #713f12; font-weight: 700;">المستحق القائم للمورد</span>
      <div style="font-size: 12.5pt; font-weight: 800; color: #a16207; margin-top: 2px;">${formatNumber(supplier.amount, finalNumberFormat)} د.ع</div>
    </div>
    <div style="background: #f8fafc; border: 1.5px solid #e2e8f0; padding: 10px 14px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #475569; font-weight: 700;">تاريخ فتح الحساب والتسجيل</span>
      <div style="font-size: 11pt; font-weight: 700; color: #334155; margin-top: 2px;">${cleanCreatedAt}</div>
    </div>
  </div>`;

  const history = Array.isArray(supplier.history) ? supplier.history : [];
  const sortedHistory = [...history].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  let txRows = '';
  if (sortedHistory.length === 0) {
    txRows = `<tr><td colspan="5" style="text-align:center; color:#64748b; padding:14px; font-weight: 700;">لا توجد حركات تسديد أو إضافة مسجلة لهذا المورد</td></tr>`;
  } else {
    sortedHistory.forEach((tx, idx) => {
      const isPay = tx.type === 'pay_supplier';
      const typeLabel = isPay ? 'تسديد دفعة' : 'قيد بضاعة/دين آجل';
      const typeClass = isPay ? 'tx-type-pay' : 'tx-type-add';
      const amountPrefix = isPay ? '-' : '+';
      const cleanDate = tx.date ? tx.date.split('T')[0].replace(/-/g, '/') : '-';
      const itemLabel = tx.itemType || supplier.itemType || '';
      const notesStr = tx.notes || tx.description || '';

      txRows += `<tr>
        <td style="width: 6%; text-align: center;"><strong>${formatNumber(idx + 1, finalNumberFormat)}</strong></td>
        <td style="width: 18%;"><span class="${typeClass}">${typeLabel}</span></td>
        <td style="width: 22%;"><strong>${amountPrefix}${formatNumber(tx.amount, finalNumberFormat)} د.ع</strong></td>
        <td style="width: 18%;">${cleanDate}</td>
        <td style="width: 36%;">
          ${itemLabel ? `<span style="display: inline-block; background: #fef3c7; color: #92400e; font-weight: 800; padding: 1px 6px; border-radius: 4px; border: 1px solid #fde68a; margin-left: 4px; font-size: 7.5pt;">السلعة: ${escapeHtml(itemLabel)}</span> ` : ''}
          ${escapeHtml(notesStr || (!itemLabel ? '-' : ''))}
        </td>
      </tr>`;
    });
  }

  const htmlSection = `<div class="person-card">
    <div class="person-card-header">
      <div>
        <div class="person-name">${escapeHtml(supplier.name)} ${supplier.companyName ? `(${escapeHtml(supplier.companyName)})` : ''}</div>
        <div class="person-phone">${cleanPhone ? `رقم الهاتف: <span style="font-family: monospace; font-size: 8.5pt;">${escapeHtml(cleanPhone)}</span> | ` : ''}تاريخ التسجيل: ${cleanCreatedAt}</div>
      </div>
      <div class="person-amount-box">
        <span class="amount-value">${formatNumber(supplier.amount, finalNumberFormat)} د.ع</span>
        <span class="amount-label">الرصيد المستحق القائم</span>
      </div>
    </div>
    <div style="padding: 6px 10px; background: #fff;">
      <table class="tx-table">
        <thead>
          <tr>
            <th style="width: 6%; text-align: center;">#</th>
            <th style="width: 18%;">نوع الحركة</th>
            <th style="width: 22%;">المبلغ</th>
            <th style="width: 18%;">التاريخ</th>
            <th style="width: 36%;">الملاحظات والتفاصيل</th>
          </tr>
        </thead>
        <tbody>
          ${txRows}
        </tbody>
      </table>
    </div>
  </div>`;

  printSystemPdfReport(
    {
      title: `كشف حساب مورد / شركة - ${supplier.name}`,
      subtitle: cleanPhone ? `رقم الهاتف: ${cleanPhone}` : '',
      branchName,
      userName,
      statsSummaryHtml,
      accentColor: 'amber',
    },
    htmlSection
  );
}

/**
 * Export Single Installment PDF Statement
 */
export function exportSingleInstallmentPdf(
  installment: InstallmentRecord,
  currentUser?: User | null,
  storeName?: string,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const activeUser = currentUser || getActiveSessionUser();
  const branchName = activeUser ? getUserBranchDisplayName(activeUser) : (storeName || 'الفرع الرئيسي');
  const userName = activeUser ? getUserDisplayName(activeUser) : 'مدير النظام';

  const userSettings = getActiveUserSettings(activeUser?.id);
  const finalNumberFormat = numberFormat || userSettings?.numberFormat || 'english';

  const cleanRegDate = installment.registrationDate ? installment.registrationDate.split('T')[0].replace(/-/g, '/') : '-';
  const cleanNextDue = installment.nextDueDate ? installment.nextDueDate.split('T')[0].replace(/-/g, '/') : '-';
  const rawInstPhone = installment.phone ? installment.phone.trim() : '';
  const cleanPhone = rawInstPhone && rawInstPhone !== 'غير مسجل' ? rawInstPhone : '';

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 12px;">
    <div style="background: #fdf4ff; border: 1.5px solid #f5d0fe; padding: 10px 14px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #701a75; font-weight: 700;">إجمالي مبلغ العقد</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #581c87; margin-top: 2px;">${formatNumber(installment.totalAmount, finalNumberFormat)} د.ع</div>
    </div>
    <div style="background: #f0fdf4; border: 1.5px solid #bbf7d0; padding: 10px 14px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #14532d; font-weight: 700;">المُسدّد والدفعة الأولى</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #15803d; margin-top: 2px;">${formatNumber(installment.totalAmount - installment.remainingAmount, finalNumberFormat)} د.ع</div>
    </div>
    <div style="background: #fff1f2; border: 1.5px solid #fecdd3; padding: 10px 14px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #881337; font-weight: 700;">المتبقي للتحصيل</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #be123c; margin-top: 2px;">${formatNumber(installment.remainingAmount, finalNumberFormat)} د.ع</div>
    </div>
  </div>`;

  const payments = Array.isArray(installment.payments) ? installment.payments : [];
  let txRows = '';
  if (payments.length === 0) {
    txRows = `<tr><td colspan="5" style="text-align:center; color:#64748b; padding:14px; font-weight: 700;">لا توجد دفعات تسديد قسط مسجلة لهذا العقد بعد</td></tr>`;
  } else {
    payments.forEach((p, pIdx) => {
      const cleanDate = p.date ? p.date.split('T')[0].replace(/-/g, '/') : '-';
      txRows += `<tr>
        <td style="width: 6%; text-align: center;"><strong>${formatNumber(pIdx + 1, finalNumberFormat)}</strong></td>
        <td style="width: 18%;"><span class="tx-type-pay">تسديد قسط</span></td>
        <td style="width: 22%;"><strong>+${formatNumber(p.amount, finalNumberFormat)} د.ع</strong></td>
        <td style="width: 18%;">${cleanDate}</td>
        <td style="width: 36%;">${escapeHtml(p.notes || '-')}</td>
      </tr>`;
    });
  }

  const htmlSection = `<div class="person-card">
    <div class="person-card-header">
      <div>
        <div class="person-name">${escapeHtml(installment.name)} <span style="font-size: 8.5pt; color: #0369a1; font-weight: 700;">[السلعة: ${escapeHtml(installment.item)}]</span></div>
        <div class="person-phone">${cleanPhone ? `رقم الهاتف: <span style="font-family: monospace; font-size: 8.5pt;">${escapeHtml(cleanPhone)}</span> | ` : ''}تاريخ العقد: ${cleanRegDate} | الاستحقاق القادم: ${cleanNextDue}</div>
      </div>
      <div class="person-amount-box">
        <span class="amount-value">${formatNumber(installment.remainingAmount, finalNumberFormat)} د.ع</span>
        <span class="amount-label">المتبقي من القسط</span>
      </div>
    </div>
    <div style="padding: 6px 10px; background: #fff;">
      <table class="tx-table">
        <thead>
          <tr>
            <th style="width: 6%; text-align: center;">#</th>
            <th style="width: 18%;">نوع الحركة</th>
            <th style="width: 22%;">المبلغ المسدد</th>
            <th style="width: 18%;">التاريخ</th>
            <th style="width: 36%;">الملاحظات والتفاصيل</th>
          </tr>
        </thead>
        <tbody>
          ${txRows}
        </tbody>
      </table>
    </div>
  </div>`;

  printSystemPdfReport(
    {
      title: `كشف حساب عقد قسط - ${installment.name}`,
      subtitle: `السلعة: ${installment.item}${cleanPhone ? ` | رقم الهاتف: ${cleanPhone}` : ''}`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor: 'emerald',
    },
    htmlSection
  );
}

/**
 * Export Suppliers List PDF Report
 */
export function exportSuppliersPdfReport(
  suppliers: Supplier[],
  currentUser?: User | null,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const activeUser = currentUser || getActiveSessionUser();
  const branchName = activeUser ? getUserBranchDisplayName(activeUser) : 'الفرع الرئيسي';
  const userName = activeUser ? getUserDisplayName(activeUser) : 'مدير النظام';

  const userSettings = getActiveUserSettings(activeUser?.id);
  const finalNumberFormat = numberFormat || userSettings?.numberFormat || 'english';

  let totalOwed = 0;
  suppliers.forEach((s) => {
    totalOwed += Number(s.amount) || 0;
  });

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 12px;">
    <div style="background: #fffbe3; border: 1.5px solid #fef08a; padding: 10px 14px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #713f12; font-weight: 700;">إجمالي مستحقات الموردين القائمة</span>
      <div style="font-size: 12.5pt; font-weight: 800; color: #a16207; margin-top: 2px;">${formatNumber(totalOwed, finalNumberFormat)} د.ع</div>
    </div>
    <div style="background: #f8fafc; border: 1.5px solid #e2e8f0; padding: 10px 14px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #475569; font-weight: 700;">إجمالي عدد الموردين والشركات</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #334155; margin-top: 2px;">${formatNumber(suppliers.length, finalNumberFormat)} مورد</div>
    </div>
  </div>`;

  let htmlSections = '';
  if (suppliers.length === 0) {
    htmlSections = '<div style="text-align: center; padding: 20px; color: #64748b; font-weight: 700;">لا يوجد موردين مسجلين</div>';
  } else {
    suppliers.forEach((sup) => {
      const cleanPhone = sup.phone ? sup.phone.replace(/[^0-9]/g, '') : 'غير مسجل';
      const cleanCreatedAt = sup.createdAt ? sup.createdAt.split('T')[0].replace(/-/g, '/') : '-';
      const history = Array.isArray(sup.history) ? sup.history : [];

      let txRows = '';
      if (history.length === 0) {
        txRows = `<tr><td colspan="5" style="text-align:center; color:#64748b; padding:10px; font-weight: 700;">لا توجد حركات مسجلة لهذا المورد</td></tr>`;
      } else {
        history.slice(-15).reverse().forEach((tx, idx) => {
          const isPay = tx.type === 'pay_supplier';
          const typeLabel = isPay ? 'تسديد دفعة' : 'قيد بضاعة/دين';
          const typeClass = isPay ? 'tx-type-pay' : 'tx-type-add';
          const amountPrefix = isPay ? '-' : '+';
          const cleanDate = tx.date ? tx.date.split('T')[0].replace(/-/g, '/') : '-';

          const itemLabel = tx.itemType || sup.itemType || '';
          const notesStr = tx.notes || tx.description || '';

          txRows += `<tr>
            <td style="width: 6%; text-align: center;"><strong>${formatNumber(idx + 1, finalNumberFormat)}</strong></td>
            <td style="width: 18%;"><span class="${typeClass}">${typeLabel}</span></td>
            <td style="width: 22%;"><strong>${amountPrefix}${formatNumber(tx.amount, finalNumberFormat)} د.ع</strong></td>
            <td style="width: 18%;">${cleanDate}</td>
            <td style="width: 36%;">
              ${itemLabel ? `<span style="display: inline-block; background: #fef3c7; color: #92400e; font-weight: 800; padding: 1px 6px; border-radius: 4px; border: 1px solid #fde68a; margin-left: 4px; font-size: 7.5pt;">السلعة: ${escapeHtml(itemLabel)}</span> ` : ''}
              ${escapeHtml(notesStr || (!itemLabel ? '-' : ''))}
            </td>
          </tr>`;
        });
      }

      htmlSections += `<div class="person-card">
        <div class="person-card-header">
          <div>
            <div class="person-name">${escapeHtml(sup.name)} ${sup.companyName ? `(${escapeHtml(sup.companyName)})` : ''}</div>
            <div class="person-phone">${cleanPhone && cleanPhone !== 'غير مسجل' ? `رقم الهاتف: <span style="font-family: monospace; font-size: 8.5pt;">${escapeHtml(cleanPhone)}</span> | ` : ''}تاريخ التسجيل: ${cleanCreatedAt}</div>
          </div>
          <div class="person-amount-box">
            <span class="amount-value">${formatNumber(sup.amount, finalNumberFormat)} د.ع</span>
            <span class="amount-label">الرصيد المستحق</span>
          </div>
        </div>
        <div style="padding: 6px 10px; background: #fff;">
          <table class="tx-table">
            <thead>
              <tr>
                <th style="width: 6%; text-align: center;">#</th>
                <th style="width: 18%;">نوع الحركة</th>
                <th style="width: 22%;">المبلغ</th>
                <th style="width: 18%;">التاريخ</th>
                <th style="width: 36%;">الملاحظات والتفاصيل</th>
              </tr>
            </thead>
            <tbody>
              ${txRows}
            </tbody>
          </table>
        </div>
      </div>`;
    });
  }

  printSystemPdfReport(
    {
      title: 'تقرير كشف حسابات الموردين والشركات الكامل',
      subtitle: `إجمالي عدد الموردين: ${formatNumber(suppliers.length, finalNumberFormat)} مورد`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor: 'amber',
    },
    htmlSections
  );
}

/**
 * Export Installments List PDF Report
 */
export function exportInstallmentsPdfReport(
  installments: InstallmentRecord[],
  currentUser?: User | null,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const activeUser = currentUser || getActiveSessionUser();
  const branchName = activeUser ? getUserBranchDisplayName(activeUser) : 'الفرع الرئيسي';
  const userName = activeUser ? getUserDisplayName(activeUser) : 'مدير النظام';

  const userSettings = getActiveUserSettings(activeUser?.id);
  const finalNumberFormat = numberFormat || userSettings?.numberFormat || 'english';

  let totalValue = 0;
  let totalRemaining = 0;
  installments.forEach((inst) => {
    totalValue += Number(inst.totalAmount) || 0;
    totalRemaining += Number(inst.remainingAmount) || 0;
  });
  const totalPaid = totalValue - totalRemaining;

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 12px;">
    <div style="background: #fdf4ff; border: 1.5px solid #f5d0fe; padding: 10px 14px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #701a75; font-weight: 700;">مجموع قيمة عقود الأقساط</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #581c87; margin-top: 2px;">${formatNumber(totalValue, finalNumberFormat)} د.ع</div>
    </div>
    <div style="background: #f0fdf4; border: 1.5px solid #bbf7d0; padding: 10px 14px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #14532d; font-weight: 700;">إجمالي المحصل والمقدمات</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #15803d; margin-top: 2px;">${formatNumber(totalPaid, finalNumberFormat)} د.ع</div>
    </div>
    <div style="background: #fff1f2; border: 1.5px solid #fecdd3; padding: 10px 14px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #881337; font-weight: 700;">المتبقي المطلوب تحصيله</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #be123c; margin-top: 2px;">${formatNumber(totalRemaining, finalNumberFormat)} د.ع</div>
    </div>
  </div>`;

  let htmlSections = '';
  if (installments.length === 0) {
    htmlSections = '<div style="text-align: center; padding: 20px; color: #64748b; font-weight: 700;">لا توجد معاملات أقساط مسجلة</div>';
  } else {
    installments.forEach((inst) => {
      const cleanPhone = inst.phone ? inst.phone.replace(/[^0-9]/g, '') : 'غير مسجل';
      const cleanRegDate = inst.registrationDate ? inst.registrationDate.split('T')[0].replace(/-/g, '/') : '-';
      const cleanNextDue = inst.nextDueDate ? inst.nextDueDate.split('T')[0].replace(/-/g, '/') : '-';
      const payments = Array.isArray(inst.payments) ? inst.payments : [];

      let txRows = '';
      if (payments.length === 0) {
        txRows = `<tr><td colspan="5" style="text-align:center; color:#64748b; padding:10px; font-weight: 700;">لا توجد دفعات تسديد مسجلة لهذا العقد بعد</td></tr>`;
      } else {
        payments.forEach((p, idx) => {
          const cleanDate = p.date ? p.date.split('T')[0].replace(/-/g, '/') : '-';
          txRows += `<tr>
            <td style="width: 6%; text-align: center;"><strong>${formatNumber(idx + 1, finalNumberFormat)}</strong></td>
            <td style="width: 18%;"><span class="tx-type-pay">تسديد قسط</span></td>
            <td style="width: 22%;"><strong>+${formatNumber(p.amount, finalNumberFormat)} د.ع</strong></td>
            <td style="width: 18%;">${cleanDate}</td>
            <td style="width: 36%;">${escapeHtml(p.notes || '-')}</td>
          </tr>`;
        });
      }

      htmlSections += `<div class="person-card">
        <div class="person-card-header">
          <div>
            <div class="person-name">${escapeHtml(inst.name)} <span style="font-size: 8.5pt; color: #0369a1; font-weight: 700;">[السلعة: ${escapeHtml(inst.item)}]</span></div>
            <div class="person-phone">${cleanPhone && cleanPhone !== 'غير مسجل' ? `رقم الهاتف: <span style="font-family: monospace; font-size: 8.5pt;">${escapeHtml(cleanPhone)}</span> | ` : ''}تاريخ العقد: ${cleanRegDate} | الاستحقاق القادم: ${cleanNextDue}</div>
          </div>
          <div class="person-amount-box">
            <span class="amount-value">${formatNumber(inst.remainingAmount, finalNumberFormat)} د.ع</span>
            <span class="amount-label">المتبقي من القسط</span>
          </div>
        </div>
        <div style="padding: 6px 10px; background: #fff;">
          <table class="tx-table">
            <thead>
              <tr>
                <th style="width: 6%; text-align: center;">#</th>
                <th style="width: 18%;">نوع الحركة</th>
                <th style="width: 22%;">المبلغ المسدد</th>
                <th style="width: 18%;">التاريخ</th>
                <th style="width: 36%;">الملاحظات والتفاصيل</th>
              </tr>
            </thead>
            <tbody>
              ${txRows}
            </tbody>
          </table>
        </div>
      </div>`;
    });
  }

  printSystemPdfReport(
    {
      title: 'تقرير عقود نظام الأقساط المالي الشامل',
      subtitle: `إجمالي المعاملات: ${formatNumber(installments.length, finalNumberFormat)} عقد`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor: 'purple',
    },
    htmlSections
  );
}
