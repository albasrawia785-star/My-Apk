import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { getUserBranchDisplayName, getUserDisplayName } from './userUtils';
import { formatNumber, formatDateDigits } from './formatters';
import { Debtor, Supplier, InstallmentRecord, User } from '../types';

interface PrintReportHeaderOptions {
  title: string;
  subtitle: string;
  branchName: string;
  userName: string;
  periodLabel?: string;
  statsSummaryHtml?: string;
  accentColor?: string; // 'blue' | 'rose' | 'emerald' | 'amber' | 'purple'
}

export async function printSystemPdfReport(
  options: PrintReportHeaderOptions,
  tableSectionsHtml: string
) {
  const { title, subtitle, branchName, userName, periodLabel, statsSummaryHtml, accentColor = 'blue' } = options;

  let headerGradient = 'linear-gradient(135deg, #1e293b, #0f172a)';
  let accentBadgeBg = '#3b82f6';
  let primaryColor = '#1e3a8a';

  if (accentColor === 'rose') {
    headerGradient = 'linear-gradient(135deg, #9f1239, #881337)';
    accentBadgeBg = '#e11d48';
    primaryColor = '#881337';
  } else if (accentColor === 'emerald') {
    headerGradient = 'linear-gradient(135deg, #065f46, #064e3b)';
    accentBadgeBg = '#10b981';
    primaryColor = '#064e3b';
  } else if (accentColor === 'amber') {
    headerGradient = 'linear-gradient(135deg, #78350f, #451a03)';
    accentBadgeBg = '#d97706';
    primaryColor = '#78350f';
  } else if (accentColor === 'purple') {
    headerGradient = 'linear-gradient(135deg, #581c87, #3b0764)';
    accentBadgeBg = '#8b5cf6';
    primaryColor = '#3b0764';
  }

  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const dateStr = `${year}/${month}/${day}`;
  
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const timeStr = `${hours}:${minutes}`;

  const cleanTitle = (title || 'تقرير_كشف_الحساب').trim().replace(/[\s/\\:*?"<>|]+/g, '_');
  const dateFile = dateStr.replace(/\//g, '-');
  const pdfFileName = `${cleanTitle}-${dateFile}.pdf`;

  // Build offscreen container for pixel-perfect PDF rendering
  const container = document.createElement('div');
  container.style.position = 'fixed';
  container.style.top = '-99999px';
  container.style.left = '-99999px';
  container.style.width = '794px'; // Standard A4 width @ 96 DPI
  container.style.backgroundColor = '#ffffff';
  container.style.color = '#1e293b';
  container.style.fontFamily = "'Cairo', 'Segoe UI', Tahoma, sans-serif";
  container.style.direction = 'rtl';
  container.style.padding = '24px';
  container.style.boxSizing = 'border-box';
  container.style.zIndex = '-9999';

  container.innerHTML = `
    <style>
      .pdf-container * {
        box-sizing: border-box;
        font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
      }
      .pdf-report-header {
        background: ${headerGradient};
        color: #ffffff;
        padding: 20px 24px;
        border-radius: 16px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
      }
      .pdf-title {
        font-size: 17pt;
        font-weight: 900;
        margin: 0 0 6px 0;
        color: #ffffff;
      }
      .pdf-subtitle {
        font-size: 9.5pt;
        opacity: 0.9;
        margin: 0;
        color: #f1f5f9;
      }
      .pdf-meta-box {
        background: rgba(255, 255, 255, 0.12);
        padding: 10px 14px;
        border-radius: 12px;
        font-size: 8.5pt;
        line-height: 1.5;
        text-align: right;
        min-width: 140px;
        color: #ffffff;
      }
      .pdf-stats-grid {
        margin-bottom: 18px;
      }
      .person-card {
        background: #ffffff;
        border: 1.5px solid #e2e8f0;
        border-radius: 14px;
        margin-bottom: 16px;
        overflow: hidden;
      }
      .person-card-header {
        background: #f8fafc;
        padding: 12px 16px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #e2e8f0;
      }
      .person-name {
        font-size: 12.5pt;
        font-weight: 800;
        color: #0f172a;
      }
      .person-phone {
        font-size: 8.5pt;
        color: #64748b;
        margin-top: 2px;
      }
      .person-amount-box {
        text-align: left;
      }
      .amount-value {
        font-size: 13pt;
        font-weight: 900;
        color: ${primaryColor};
        display: block;
      }
      .amount-label {
        font-size: 7.5pt;
        color: #64748b;
      }
      .tx-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 8.5pt;
        margin-top: 4px;
      }
      .tx-table th {
        background-color: #f1f5f9;
        color: #334155;
        padding: 8px 10px;
        text-align: right;
        font-weight: 800;
        border-bottom: 2px solid #cbd5e1;
      }
      .tx-table td {
        padding: 8px 10px;
        border-bottom: 1px solid #f1f5f9;
        color: #1e293b;
        text-align: right;
      }
      .tx-table tr:nth-child(even) td {
        background-color: #fafafa;
      }
      .tx-type-pay {
        color: #047857;
        font-weight: 800;
        background: #d1fae5;
        padding: 2px 7px;
        border-radius: 6px;
        font-size: 8pt;
      }
      .tx-type-add {
        color: #be123c;
        font-weight: 800;
        background: #ffe4e6;
        padding: 2px 7px;
        border-radius: 6px;
        font-size: 8pt;
      }
      .tx-type-info {
        color: #0369a1;
        font-weight: 800;
        background: #e0f2fe;
        padding: 2px 7px;
        border-radius: 6px;
        font-size: 8pt;
      }
      .pdf-footer {
        margin-top: 20px;
        padding-top: 10px;
        border-top: 1.5px solid #e2e8f0;
        font-size: 8pt;
        color: #64748b;
        display: flex;
        justify-content: space-between;
      }
    </style>

    <div class="pdf-container">
      <div class="pdf-report-header">
        <div>
          <h1 class="pdf-title">${title}</h1>
          <p class="pdf-subtitle">${subtitle}</p>
          ${periodLabel ? `<p class="pdf-subtitle" style="margin-top: 4px; font-weight: 700;">فترة التقرير: ${periodLabel}</p>` : ''}
        </div>
        <div class="pdf-meta-box">
          <div style="font-weight: 800;">فرع: ${branchName}</div>
          <div>${dateStr} - ${timeStr}</div>
          <div style="opacity: 0.85;">المستخدم: ${userName}</div>
        </div>
      </div>

      ${statsSummaryHtml ? `<div class="pdf-stats-grid">${statsSummaryHtml}</div>` : ''}

      <div class="pdf-content">
        ${tableSectionsHtml}
      </div>

      <div class="pdf-footer">
        <div>تم استخراج هذا التقرير المعتمد آلياً بواسطة تطبيق دفتر الديون للأعمال</div>
        <div>تاريخ الإصدار: ${dateStr}</div>
      </div>
    </div>
  `;

  document.body.appendChild(container);

  try {
    const canvas = await html2canvas(container, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff'
    });

    const imgData = canvas.toDataURL('image/jpeg', 0.96);
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const imgWidth = 210; // A4 width in mm
    const pageHeight = 297; // A4 height in mm
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft > 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    const pdfBlob = pdf.output('blob');
    const pdfFile = new File([pdfBlob], pdfFileName, { type: 'application/pdf' });

    // 1. Try Native Share API (WhatsApp, Telegram, Google Drive, Files, etc.)
    let sharedSuccessfully = false;
    if (navigator.canShare && navigator.canShare({ files: [pdfFile] })) {
      try {
        await navigator.share({
          files: [pdfFile],
          title: title,
          text: `${title} - ${branchName}`
        });
        sharedSuccessfully = true;
      } catch (shareErr: any) {
        if (shareErr && shareErr.name === 'AbortError') {
          sharedSuccessfully = true; // User intentionally dismissed share
        }
      }
    }

    // 2. Direct PDF File Download fallback (for desktop or when sharing is unavailable)
    if (!sharedSuccessfully) {
      pdf.save(pdfFileName);
    }
  } catch (err) {
    console.error('PDF Generation Error:', err);
    window.print();
  } finally {
    if (document.body.contains(container)) {
      document.body.removeChild(container);
    }
  }
}

export function exportSingleDebtorPdf(
  debtor: Debtor,
  currentUser?: User | null,
  storeName?: string,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const branchName = currentUser ? getUserBranchDisplayName(currentUser) : (storeName || 'الفرع الرئيسي');
  const userName = currentUser ? getUserDisplayName(currentUser) : 'مدير النظام';

  const isCreditor = debtor.type === 'creditor';
  const reportTitle = isCreditor ? `كشف حساب دائن (التزام مالي) - ${debtor.name}` : `كشف حساب زبون (مدين) - ${debtor.name}`;
  const accentColor = isCreditor ? 'rose' : 'blue';

  const cleanCreatedAt = debtor.createdAt ? debtor.createdAt.split('T')[0].replace(/-/g, '/') : '-';

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 20px;">
    <div style="background: ${isCreditor ? '#fff1f2' : '#eff6ff'}; border: 1px solid ${isCreditor ? '#fecdd3' : '#bfdbfe'}; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: ${isCreditor ? '#881337' : '#1e3a8a'}; font-weight: 700;">الرصيد المالي القائم</span>
      <div style="font-size: 14pt; font-weight: 900; color: ${isCreditor ? '#be123c' : '#1d4ed8'};">${formatNumber(debtor.amount, numberFormat)} د.ع</div>
    </div>
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: #475569; font-weight: 700;">تاريخ فتح الحساب والتسجيل</span>
      <div style="font-size: 12pt; font-weight: 800; color: #334155;">${cleanCreatedAt}</div>
    </div>
  </div>`;

  const rawHistory = debtor.history && debtor.history.length > 0
    ? debtor.history
    : [
        {
          id: `initial-${debtor.id}`,
          debtorId: debtor.id,
          type: 'initial' as const,
          amount: debtor.amount,
          balanceAfter: debtor.amount,
          date: debtor.createdAt || new Date().toISOString(),
          description: 'فتح حساب وتسجيل الرصيد الأولي',
        },
      ];

  const sortedHistory = [...rawHistory].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  let txRows = '';
  if (sortedHistory.length === 0) {
    txRows = `<tr><td colspan="5" class="no-history">لا توجد حركات تسديد أو إضافة مسجلة لهذا الحساب</td></tr>`;
  } else {
    sortedHistory.forEach((tx, idx) => {
      const isPay = tx.type === 'pay';
      const isInitial = tx.type === 'initial';
      const typeLabel = isPay ? 'تسديد دفعة' : isInitial ? 'رصيد افتتاحي' : (isCreditor ? 'دين عليّ إضافي' : 'دين جديد');
      const typeClass = isPay ? 'tx-type-pay' : isInitial ? 'tx-type-info' : 'tx-type-add';
      const amountPrefix = isPay ? '-' : '+';
      const cleanDate = tx.date ? tx.date.split('T')[0].replace(/-/g, '/') : '-';

      txRows += `<tr>
        <td><strong>${formatNumber(idx + 1, numberFormat)}</strong></td>
        <td><span class="${typeClass}">${typeLabel}</span></td>
        <td><strong>${amountPrefix}${formatNumber(tx.amount, numberFormat)} د.ع</strong></td>
        <td>${cleanDate}</td>
        <td>${tx.notes || tx.description || '-'}</td>
      </tr>`;
    });
  }

  const cleanPhone = debtor.phone ? debtor.phone.replace(/[^0-9]/g, '') : 'غير مسجل';

  const htmlSection = `<div class="person-card">
    <div class="person-card-header">
      <div>
        <div class="person-name">${debtor.name}</div>
        <div class="person-phone">رقم الهاتف: ${cleanPhone} | تاريخ التسجيل: ${cleanCreatedAt}</div>
      </div>
      <div class="person-amount-box">
        <span class="amount-value">${formatNumber(debtor.amount, numberFormat)} د.ع</span>
        <span class="amount-label">الرصيد القائم</span>
      </div>
    </div>
    <div style="padding: 10px 14px; background: #fff;">
      <table class="tx-table">
        <thead>
          <tr>
            <th style="width: 30px;">#</th>
            <th style="width: 120px;">نوع الحركة</th>
            <th style="width: 120px;">المبلغ</th>
            <th style="width: 110px;">التاريخ</th>
            <th>الملاحظات والتفاصيل</th>
          </tr>
        </thead>
        <tbody>
          ${txRows}
        </tbody>
      </table>
    </div>
  </div>`;

  printSystemPdfReport(
    {
      title: reportTitle,
      subtitle: `رقم الهاتف: ${cleanPhone}`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor,
    },
    htmlSection
  );
}

export function exportSingleSupplierPdf(
  supplier: Supplier,
  currentUser?: User | null,
  storeName?: string,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const branchName = currentUser ? getUserBranchDisplayName(currentUser) : (storeName || 'الفرع الرئيسي');
  const userName = currentUser ? getUserDisplayName(currentUser) : 'مدير النظام';

  const cleanCreatedAt = supplier.createdAt ? supplier.createdAt.split('T')[0].replace(/-/g, '/') : '-';
  const cleanPhone = supplier.phone ? supplier.phone.replace(/[^0-9]/g, '') : 'غير مسجل';

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 20px;">
    <div style="background: #fffbe3; border: 1px solid #fef08a; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: #713f12; font-weight: 700;">المستحق القائم للمورد</span>
      <div style="font-size: 14pt; font-weight: 900; color: #a16207;">${formatNumber(supplier.amount, numberFormat)} د.ع</div>
    </div>
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: #475569; font-weight: 700;">نوع البضائع / الشركة</span>
      <div style="font-size: 12pt; font-weight: 800; color: #334155;">${supplier.companyName || supplier.itemType || 'غير محدد'}</div>
    </div>
  </div>`;

  const history = supplier.history || [];
  const sortedHistory = [...history].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  let txRows = '';
  if (sortedHistory.length === 0) {
    txRows = `<tr><td colspan="5" class="no-history">لا توجد حركات تسديد أو إضافة مسجلة لهذا المورد</td></tr>`;
  } else {
    sortedHistory.forEach((tx, idx) => {
      const isPay = tx.type === 'pay_supplier';
      const typeLabel = isPay ? 'تسديد دفعة' : 'قيد بضاعة/دين آجل';
      const typeClass = isPay ? 'tx-type-pay' : 'tx-type-add';
      const amountPrefix = isPay ? '-' : '+';
      const cleanDate = tx.date ? tx.date.split('T')[0].replace(/-/g, '/') : '-';

      txRows += `<tr>
        <td><strong>${formatNumber(idx + 1, numberFormat)}</strong></td>
        <td><span class="${typeClass}">${typeLabel}</span></td>
        <td><strong>${amountPrefix}${formatNumber(tx.amount, numberFormat)} د.ع</strong></td>
        <td>${cleanDate}</td>
        <td>${tx.itemType ? `[بضاعة: ${tx.itemType}] ` : ''}${tx.notes || tx.description || '-'}</td>
      </tr>`;
    });
  }

  const htmlSection = `<div class="person-card">
    <div class="person-card-header">
      <div>
        <div class="person-name">${supplier.name} ${supplier.companyName ? `(${supplier.companyName})` : ''}</div>
        <div class="person-phone">رقم الهاتف: ${cleanPhone} | تاريخ التسجيل: ${cleanCreatedAt}</div>
      </div>
      <div class="person-amount-box">
        <span class="amount-value">${formatNumber(supplier.amount, numberFormat)} د.ع</span>
        <span class="amount-label">الرصيد المستحق القائم</span>
      </div>
    </div>
    <div style="padding: 10px 14px; background: #fff;">
      <table class="tx-table">
        <thead>
          <tr>
            <th style="width: 30px;">#</th>
            <th style="width: 120px;">نوع الحركة</th>
            <th style="width: 120px;">المبلغ</th>
            <th style="width: 110px;">التاريخ</th>
            <th>الملاحظات والتفاصيل</th>
          </tr>
        </thead>
        <tbody>
          ${txRows}
        </tbody>
      </table>
    </div>
  </div>`;

  printSystemPdfReport(
    {
      title: `كشف حساب مورد / شركة - ${supplier.name}`,
      subtitle: `رقم الهاتف: ${cleanPhone} ${supplier.itemType ? `| السلعة: ${supplier.itemType}` : ''}`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor: 'amber',
    },
    htmlSection
  );
}

export function exportSingleInstallmentPdf(
  installment: InstallmentRecord,
  currentUser?: User | null,
  storeName?: string,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const branchName = currentUser ? getUserBranchDisplayName(currentUser) : (storeName || 'الفرع الرئيسي');
  const userName = currentUser ? getUserDisplayName(currentUser) : 'مدير النظام';

  const cleanRegDate = installment.registrationDate ? installment.registrationDate.split('T')[0].replace(/-/g, '/') : '-';
  const cleanNextDue = installment.nextDueDate ? installment.nextDueDate.split('T')[0].replace(/-/g, '/') : '-';
  const cleanPhone = installment.phone ? installment.phone.replace(/[^0-9]/g, '') : 'غير مسجل';

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 20px;">
    <div style="background: #fdf4ff; border: 1px solid #f5d0fe; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: #701a75; font-weight: 700;">إجمالي مبلغ العقد</span>
      <div style="font-size: 13pt; font-weight: 900; color: #581c87;">${formatNumber(installment.totalAmount, numberFormat)} د.ع</div>
    </div>
    <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: #14532d; font-weight: 700;">المُسدّد والدفعة الأولى</span>
      <div style="font-size: 13pt; font-weight: 900; color: #15803d;">${formatNumber(installment.totalAmount - installment.remainingAmount, numberFormat)} د.ع</div>
    </div>
    <div style="background: #fff1f2; border: 1px solid #fecdd3; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: #881337; font-weight: 700;">المتبقي للتحصيل</span>
      <div style="font-size: 13pt; font-weight: 900; color: #be123c;">${formatNumber(installment.remainingAmount, numberFormat)} د.ع</div>
    </div>
  </div>`;

  const payments = installment.payments || [];
  let txRows = '';
  if (payments.length === 0) {
    txRows = `<tr><td colspan="5" class="no-history">لا توجد دفعات تسديد قسط مسجلة لهذا العقد بعد</td></tr>`;
  } else {
    payments.forEach((p, pIdx) => {
      const cleanDate = p.date ? p.date.split('T')[0].replace(/-/g, '/') : '-';
      txRows += `<tr>
        <td><strong>${formatNumber(pIdx + 1, numberFormat)}</strong></td>
        <td><span class="tx-type-pay">تسديد قسط</span></td>
        <td><strong>+${formatNumber(p.amount, numberFormat)} د.ع</strong></td>
        <td>${cleanDate}</td>
        <td>${p.notes || '-'}</td>
      </tr>`;
    });
  }

  const htmlSection = `<div class="person-card">
    <div class="person-card-header">
      <div>
        <div class="person-name">${installment.name} <span style="font-size: 9.5pt; color: #0369a1; font-weight: 800;">[السلعة: ${installment.item}]</span></div>
        <div class="person-phone">رقم الهاتف: ${cleanPhone} | تاريخ العقد: ${cleanRegDate} | الاستحقاق القادم: ${cleanNextDue}</div>
      </div>
      <div class="person-amount-box">
        <span class="amount-value">${formatNumber(installment.remainingAmount, numberFormat)} د.ع</span>
        <span class="amount-label">المتبقي من القسط</span>
      </div>
    </div>
    <div style="padding: 10px 14px; background: #fff;">
      <table class="tx-table">
        <thead>
          <tr>
            <th style="width: 30px;">#</th>
            <th style="width: 120px;">نوع الحركة</th>
            <th style="width: 120px;">المبلغ المسدد</th>
            <th style="width: 110px;">التاريخ</th>
            <th>الملاحظات والتفاصيل</th>
          </tr>
        </thead>
        <tbody>
          ${txRows}
        </tbody>
      </table>
    </div>
  </div>`;

  printSystemPdfReport(
    {
      title: `كشف حساب عقد قسط - ${installment.name}`,
      subtitle: `السلعة: ${installment.item} | رقم الهاتف: ${cleanPhone}`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor: 'emerald',
    },
    htmlSection
  );
}
