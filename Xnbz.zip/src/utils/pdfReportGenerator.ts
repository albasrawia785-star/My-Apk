import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { getUserBranchDisplayName, getUserDisplayName } from './userUtils';
import { formatNumber, formatDateDigits } from './formatters';
import { Debtor, Supplier, InstallmentRecord, User } from '../types';

interface PrintReportHeaderOptions {
  title: string;
  subtitle: string;
  branchName: string;
  userName: string;
  periodLabel?: string;
  statsSummaryHtml?: string;
  accentColor?: string; // 'blue' | 'rose' | 'emerald' | 'amber' | 'purple'
}

function createPdfProgressBarUI(reportTitle: string) {
  const existing = document.getElementById('pdf-generation-loading-overlay');
  if (existing) existing.remove();

  const overlay = document.createElement('div');
  overlay.id = 'pdf-generation-loading-overlay';
  overlay.style.position = 'fixed';
  overlay.style.inset = '0';
  overlay.style.backgroundColor = 'rgba(15, 23, 42, 0.7)';
  overlay.style.backdropFilter = 'blur(6px)';
  overlay.style.webkitBackdropFilter = 'blur(6px)';
  overlay.style.zIndex = '999999';
  overlay.style.display = 'flex';
  overlay.style.alignItems = 'center';
  overlay.style.justifyContent = 'center';
  overlay.style.padding = '16px';
  overlay.style.direction = 'rtl';
  overlay.style.fontFamily = "system-ui, -apple-system, 'Segoe UI', Roboto, 'Cairo', 'Arial', sans-serif";

  const displayTitle = reportTitle.length > 34 ? `${reportTitle.slice(0, 34)}...` : reportTitle;

  overlay.innerHTML = `
    <div style="
      background: #ffffff;
      border-radius: 24px;
      padding: 24px 20px;
      width: 100%;
      max-width: 420px;
      box-shadow: 0 25px 50px -12px rgba(0,0,0,0.35);
      border: 1px solid #e2e8f0;
      text-align: right;
      animation: pdfPopIn 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    ">
      <style>
        @keyframes pdfPopIn {
          from { opacity: 0; transform: scale(0.92) translateY(12px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }
      </style>
      
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
        <div style="display: flex; align-items: center; gap: 10px;">
          <div style="
            width: 42px;
            height: 42px;
            border-radius: 16px;
            background: linear-gradient(135deg, #eff6ff, #dbeafe);
            color: #2563eb;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 19px;
            box-shadow: 0 4px 12px rgba(37,99,235,0.15);
            border: 1px solid #bfdbfe;
          ">
            <i class="fa-solid fa-file-pdf"></i>
          </div>
          <div>
            <div style="font-size: 13.5px; font-weight: 800; color: #0f172a; line-height: 1.2;">جاري إصدار تقرير الـ PDF</div>
            <div style="font-size: 11px; color: #64748b; margin-top: 2px;" id="pdf-report-subtitle">${displayTitle}</div>
          </div>
        </div>
        <div id="pdf-percent-badge" style="
          font-size: 12.5px;
          font-weight: 900;
          font-family: monospace;
          color: #2563eb;
          background: #eff6ff;
          padding: 4px 12px;
          border-radius: 12px;
          border: 1px solid #bfdbfe;
        ">0%</div>
      </div>

      <!-- Glowing Animated Progress Bar Track -->
      <div style="
        width: 100%;
        height: 10px;
        background: #f1f5f9;
        border-radius: 999px;
        overflow: hidden;
        margin: 14px 0 10px 0;
        position: relative;
        border: 1px solid #e2e8f0;
      ">
        <div id="pdf-progress-bar-fill" style="
          width: 0%;
          height: 100%;
          background: linear-gradient(90deg, #2563eb, #4f46e5, #059669);
          border-radius: 999px;
          transition: width 0.35s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 0 0 10px rgba(37,99,235,0.5);
        "></div>
      </div>

      <div style="display: flex; align-items: center; justify-content: space-between; font-size: 11px; color: #64748b;">
        <span id="pdf-progress-status-text" style="font-weight: 700; color: #334155;">جاري تجهيز محتوى المستند والجداول...</span>
        <span style="display: flex; align-items: center; gap: 4px;">
          <i class="fa-solid fa-circle-notch fa-spin" style="color: #2563eb;"></i>
        </span>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
}

function updatePdfProgressBar(percent: number, statusText: string) {
  const badge = document.getElementById('pdf-percent-badge');
  const fill = document.getElementById('pdf-progress-bar-fill');
  const text = document.getElementById('pdf-progress-status-text');

  if (badge) badge.innerText = `${percent}%`;
  if (fill) fill.style.width = `${percent}%`;
  if (text) text.innerText = statusText;
}

function removePdfProgressBarUI() {
  const overlay = document.getElementById('pdf-generation-loading-overlay');
  if (overlay) {
    updatePdfProgressBar(100, 'تم إكمال ملف الـ PDF بنجاح!');
    setTimeout(() => {
      if (document.body.contains(overlay)) {
        document.body.removeChild(overlay);
      }
    }, 450);
  }
}

/**
 * Generates a lightweight, compact PDF with crisp Arabic text rendering.
 * Optimized for small file size and native APK share / download.
 */
export async function printSystemPdfReport(
  options: PrintReportHeaderOptions,
  tableSectionsHtml: string
) {
  const { title, subtitle, branchName, userName, periodLabel, statsSummaryHtml, accentColor = 'blue' } = options;

  createPdfProgressBarUI(title);
  updatePdfProgressBar(10, 'جاري تجهيز بيانات كشف الحساب والجداول...');

  let headerGradient = 'linear-gradient(135deg, #1e293b, #0f172a)';
  let primaryColor = '#1e3a8a';

  if (accentColor === 'rose') {
    headerGradient = 'linear-gradient(135deg, #881337, #4c0519)';
    primaryColor = '#881337';
  } else if (accentColor === 'emerald') {
    headerGradient = 'linear-gradient(135deg, #064e3b, #022c22)';
    primaryColor = '#064e3b';
  } else if (accentColor === 'amber') {
    headerGradient = 'linear-gradient(135deg, #78350f, #451a03)';
    primaryColor = '#78350f';
  } else if (accentColor === 'purple') {
    headerGradient = 'linear-gradient(135deg, #581c87, #3b0764)';
    primaryColor = '#3b0764';
  }

  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const dateStr = `${year}/${month}/${day}`;

  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const timeStr = `${hours}:${minutes}`;

  const cleanTitle = (title || 'تقرير_كشف_الحساب').trim().replace(/[\s/\\:*?"<>|]+/g, '_');
  const dateFile = dateStr.replace(/\//g, '-');
  const pdfFileName = `${cleanTitle}-${dateFile}.pdf`;

  // Build offscreen container with lightweight, compact dimensions
  const container = document.createElement('div');
  container.style.position = 'fixed';
  container.style.top = '-99999px';
  container.style.left = '-99999px';
  container.style.width = '700px'; // Compact width for clean rendering & smaller memory
  container.style.backgroundColor = '#ffffff';
  container.style.color = '#0f172a';
  container.style.fontFamily = "system-ui, -apple-system, 'Segoe UI', Roboto, 'Cairo', 'Arial', sans-serif";
  container.style.direction = 'rtl';
  container.style.padding = '16px';
  container.style.boxSizing = 'border-box';
  container.style.zIndex = '-9999';

  container.innerHTML = `
    <style>
      .pdf-container * {
        box-sizing: border-box;
        font-family: system-ui, -apple-system, 'Segoe UI', Roboto, 'Cairo', 'Arial', sans-serif;
      }
      .pdf-report-header {
        background: ${headerGradient};
        color: #ffffff;
        padding: 14px 18px;
        border-radius: 12px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 14px;
      }
      .pdf-title {
        font-size: 14pt;
        font-weight: 800;
        margin: 0 0 4px 0;
        color: #ffffff;
      }
      .pdf-subtitle {
        font-size: 8.5pt;
        opacity: 0.9;
        margin: 0;
        color: #f1f5f9;
      }
      .pdf-meta-box {
        background: rgba(255, 255, 255, 0.15);
        padding: 8px 12px;
        border-radius: 8px;
        font-size: 8pt;
        line-height: 1.4;
        text-align: right;
        min-width: 130px;
        color: #ffffff;
      }
      .pdf-stats-grid {
        margin-bottom: 14px;
      }
      .person-card {
        background: #ffffff;
        border: 1px solid #cbd5e1;
        border-radius: 10px;
        margin-bottom: 12px;
        overflow: hidden;
      }
      .person-card-header {
        background: #f8fafc;
        padding: 10px 14px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #e2e8f0;
      }
      .person-name {
        font-size: 11pt;
        font-weight: 800;
        color: #0f172a;
      }
      .person-phone {
        font-size: 8pt;
        color: #64748b;
        margin-top: 2px;
      }
      .person-amount-box {
        text-align: left;
      }
      .amount-value {
        font-size: 11.5pt;
        font-weight: 800;
        color: ${primaryColor};
        display: block;
      }
      .amount-label {
        font-size: 7pt;
        color: #64748b;
      }
      .tx-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 8pt;
        margin-top: 2px;
      }
      .tx-table th {
        background-color: #f1f5f9;
        color: #334155;
        padding: 6px 8px;
        text-align: right;
        font-weight: 700;
        border-bottom: 1.5px solid #cbd5e1;
      }
      .tx-table td {
        padding: 6px 8px;
        border-bottom: 1px solid #f1f5f9;
        color: #1e293b;
        text-align: right;
      }
      .tx-table tr:nth-child(even) td {
        background-color: #fafafa;
      }
      .tx-type-pay {
        color: #047857;
        font-weight: 700;
        background: #d1fae5;
        padding: 1px 6px;
        border-radius: 4px;
        font-size: 7.5pt;
      }
      .tx-type-add {
        color: #be123c;
        font-weight: 700;
        background: #ffe4e6;
        padding: 1px 6px;
        border-radius: 4px;
        font-size: 7.5pt;
      }
      .tx-type-info {
        color: #0369a1;
        font-weight: 700;
        background: #e0f2fe;
        padding: 1px 6px;
        border-radius: 4px;
        font-size: 7.5pt;
      }
      .pdf-footer {
        margin-top: 14px;
        padding-top: 8px;
        border-top: 1px solid #e2e8f0;
        font-size: 7.5pt;
        color: #64748b;
        display: flex;
        justify-content: space-between;
      }
    </style>

    <div class="pdf-container">
      <div class="pdf-report-header">
        <div>
          <h1 class="pdf-title">${title}</h1>
          <p class="pdf-subtitle">${subtitle}</p>
          ${periodLabel ? `<p class="pdf-subtitle" style="margin-top: 3px; font-weight: 700;">فترة التقرير: ${periodLabel}</p>` : ''}
        </div>
        <div class="pdf-meta-box">
          <div style="font-weight: 800;">فرع: ${branchName}</div>
          <div>${dateStr} - ${timeStr}</div>
          <div style="opacity: 0.85;">المستخدم: ${userName}</div>
        </div>
      </div>

      ${statsSummaryHtml ? `<div class="pdf-stats-grid">${statsSummaryHtml}</div>` : ''}

      <div class="pdf-content">
        ${tableSectionsHtml}
      </div>

      <div class="pdf-footer">
        <div>تم التصدير آلياً بواسطة نظام إدارة الديون للحسابات</div>
        <div>تاريخ الإصدار: ${dateStr}</div>
      </div>
    </div>
  `;

  document.body.appendChild(container);

  try {
    updatePdfProgressBar(35, 'جاري تحويل ومعالجة النصوص العربية وتنسيق الصفحة...');
    await new Promise((resolve) => setTimeout(resolve, 80));

    // Render with scale 1.4 for small image payload & fast execution
    const canvas = await html2canvas(container, {
      scale: 1.4,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
    });

    updatePdfProgressBar(70, 'جاري ضغط الصور وإنشاء ملف الـ PDF المتكامل...');
    await new Promise((resolve) => setTimeout(resolve, 50));

    // JPEG quality 0.75 produces a very lightweight PDF file (50KB - 200KB)
    const imgData = canvas.toDataURL('image/jpeg', 0.75);
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    const imgWidth = 210; // A4 width in mm
    const pageHeight = 297; // A4 height in mm
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight, undefined, 'FAST');
    heightLeft -= pageHeight;

    while (heightLeft > 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight, undefined, 'FAST');
      heightLeft -= pageHeight;
    }

    updatePdfProgressBar(95, 'جاري فتح حوار التنزيل والمشاركة...');
    await new Promise((resolve) => setTimeout(resolve, 50));

    const pdfBlob = pdf.output('blob');
    const pdfFile = new File([pdfBlob], pdfFileName, { type: 'application/pdf' });

    // 1. Check if running inside Capacitor Android APK
    const win = window as any;
    if (win.Capacitor && win.Capacitor.Plugins) {
      try {
        const { Filesystem, Share } = win.Capacitor.Plugins;
        const base64Data = pdf.output('datauristring').split(',')[1];

        if (Filesystem) {
          const savedFile = await Filesystem.writeFile({
            path: pdfFileName,
            data: base64Data,
            directory: 'CACHE',
          });

          if (Share && savedFile && savedFile.uri) {
            await Share.share({
              title: title,
              text: `${title} - ${branchName}`,
              url: savedFile.uri,
              dialogTitle: 'حفظ أو مشاركة تقرير PDF',
            });
            return;
          }
        }
      } catch (capErr) {
        console.warn('Capacitor native PDF share failed, falling back to Web APIs:', capErr);
      }
    }

    // 2. Try Native Share API (WhatsApp, Telegram, Files, etc.)
    let sharedSuccessfully = false;
    if (navigator.canShare && navigator.canShare({ files: [pdfFile] })) {
      try {
        await navigator.share({
          files: [pdfFile],
          title: title,
          text: `${title} - ${branchName}`,
        });
        sharedSuccessfully = true;
      } catch (shareErr: any) {
        if (shareErr && shareErr.name === 'AbortError') {
          sharedSuccessfully = true; // User intentionally closed share dialog
        }
      }
    }

    // 3. Direct File Download fallback
    if (!sharedSuccessfully) {
      pdf.save(pdfFileName);
    }
  } catch (err) {
    console.error('PDF Generation Error:', err);
    window.print();
  } finally {
    removePdfProgressBarUI();
    if (document.body.contains(container)) {
      document.body.removeChild(container);
    }
  }
}

/**
 * Export Single Debtor PDF Statement
 */
export function exportSingleDebtorPdf(
  debtor: Debtor,
  currentUser?: User | null,
  storeName?: string,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const branchName = currentUser ? getUserBranchDisplayName(currentUser) : (storeName || 'الفرع الرئيسي');
  const userName = currentUser ? getUserDisplayName(currentUser) : 'مدير النظام';

  const isCreditor = debtor.type === 'creditor';
  const reportTitle = isCreditor ? `كشف حساب دائن (التزام مالي) - ${debtor.name}` : `كشف حساب زبون (مدين) - ${debtor.name}`;
  const accentColor = isCreditor ? 'rose' : 'blue';

  const cleanCreatedAt = debtor.createdAt ? debtor.createdAt.split('T')[0].replace(/-/g, '/') : '-';

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 14px;">
    <div style="background: ${isCreditor ? '#fff1f2' : '#eff6ff'}; border: 1px solid ${isCreditor ? '#fecdd3' : '#bfdbfe'}; padding: 10px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: ${isCreditor ? '#881337' : '#1e3a8a'}; font-weight: 700;">الرصيد المالي القائم</span>
      <div style="font-size: 12pt; font-weight: 800; color: ${isCreditor ? '#be123c' : '#1d4ed8'};">${formatNumber(debtor.amount, numberFormat)} د.ع</div>
    </div>
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #475569; font-weight: 700;">تاريخ فتح الحساب والتسجيل</span>
      <div style="font-size: 10.5pt; font-weight: 700; color: #334155;">${cleanCreatedAt}</div>
    </div>
  </div>`;

  const rawHistory = debtor.history && debtor.history.length > 0
    ? debtor.history
    : [
        {
          id: `initial-${debtor.id}`,
          debtorId: debtor.id,
          type: 'initial' as const,
          amount: debtor.amount,
          balanceAfter: debtor.amount,
          date: debtor.createdAt || new Date().toISOString(),
          description: 'فتح حساب وتسجيل الرصيد الأولي',
        },
      ];

  const sortedHistory = [...rawHistory].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  let txRows = '';
  if (sortedHistory.length === 0) {
    txRows = `<tr><td colspan="5" style="text-align:center; color:#64748b; padding:12px;">لا توجد حركات تسديد أو إضافة مسجلة لهذا الحساب</td></tr>`;
  } else {
    sortedHistory.forEach((tx, idx) => {
      const isPay = tx.type === 'pay';
      const isInitial = tx.type === 'initial';
      const typeLabel = isPay ? 'تسديد دفعة' : isInitial ? 'رصيد افتتاحي' : (isCreditor ? 'دين عليّ إضافي' : 'دين جديد');
      const typeClass = isPay ? 'tx-type-pay' : isInitial ? 'tx-type-info' : 'tx-type-add';
      const amountPrefix = isPay ? '-' : '+';
      const cleanDate = tx.date ? tx.date.split('T')[0].replace(/-/g, '/') : '-';

      txRows += `<tr>
        <td><strong>${formatNumber(idx + 1, numberFormat)}</strong></td>
        <td><span class="${typeClass}">${typeLabel}</span></td>
        <td><strong>${amountPrefix}${formatNumber(tx.amount, numberFormat)} د.ع</strong></td>
        <td>${cleanDate}</td>
        <td>${tx.notes || tx.description || '-'}</td>
      </tr>`;
    });
  }

  const cleanPhone = debtor.phone ? debtor.phone.replace(/[^0-9]/g, '') : 'غير مسجل';

  const htmlSection = `<div class="person-card">
    <div class="person-card-header">
      <div>
        <div class="person-name">${debtor.name}</div>
        <div class="person-phone">رقم الهاتف: ${cleanPhone} | تاريخ التسجيل: ${cleanCreatedAt}</div>
      </div>
      <div class="person-amount-box">
        <span class="amount-value">${formatNumber(debtor.amount, numberFormat)} د.ع</span>
        <span class="amount-label">الرصيد القائم</span>
      </div>
    </div>
    <div style="padding: 8px 12px; background: #fff;">
      <table class="tx-table">
        <thead>
          <tr>
            <th style="width: 25px;">#</th>
            <th style="width: 100px;">نوع الحركة</th>
            <th style="width: 110px;">المبلغ</th>
            <th style="width: 95px;">التاريخ</th>
            <th>الملاحظات والتفاصيل</th>
          </tr>
        </thead>
        <tbody>
          ${txRows}
        </tbody>
      </table>
    </div>
  </div>`;

  printSystemPdfReport(
    {
      title: reportTitle,
      subtitle: `رقم الهاتف: ${cleanPhone}`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor,
    },
    htmlSection
  );
}

/**
 * Export Single Supplier PDF Statement
 */
export function exportSingleSupplierPdf(
  supplier: Supplier,
  currentUser?: User | null,
  storeName?: string,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const branchName = currentUser ? getUserBranchDisplayName(currentUser) : (storeName || 'الفرع الرئيسي');
  const userName = currentUser ? getUserDisplayName(currentUser) : 'مدير النظام';

  const cleanCreatedAt = supplier.createdAt ? supplier.createdAt.split('T')[0].replace(/-/g, '/') : '-';
  const cleanPhone = supplier.phone ? supplier.phone.replace(/[^0-9]/g, '') : 'غير مسجل';

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 14px;">
    <div style="background: #fffbe3; border: 1px solid #fef08a; padding: 10px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #713f12; font-weight: 700;">المستحق القائم للمورد</span>
      <div style="font-size: 12pt; font-weight: 800; color: #a16207;">${formatNumber(supplier.amount, numberFormat)} د.ع</div>
    </div>
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #475569; font-weight: 700;">نوع البضائع / الشركة</span>
      <div style="font-size: 10.5pt; font-weight: 700; color: #334155;">${supplier.companyName || supplier.itemType || 'غير محدد'}</div>
    </div>
  </div>`;

  const history = supplier.history || [];
  const sortedHistory = [...history].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  let txRows = '';
  if (sortedHistory.length === 0) {
    txRows = `<tr><td colspan="5" style="text-align:center; color:#64748b; padding:12px;">لا توجد حركات تسديد أو إضافة مسجلة لهذا المورد</td></tr>`;
  } else {
    sortedHistory.forEach((tx, idx) => {
      const isPay = tx.type === 'pay_supplier';
      const typeLabel = isPay ? 'تسديد دفعة' : 'قيد بضاعة/دين آجل';
      const typeClass = isPay ? 'tx-type-pay' : 'tx-type-add';
      const amountPrefix = isPay ? '-' : '+';
      const cleanDate = tx.date ? tx.date.split('T')[0].replace(/-/g, '/') : '-';

      txRows += `<tr>
        <td><strong>${formatNumber(idx + 1, numberFormat)}</strong></td>
        <td><span class="${typeClass}">${typeLabel}</span></td>
        <td><strong>${amountPrefix}${formatNumber(tx.amount, numberFormat)} د.ع</strong></td>
        <td>${cleanDate}</td>
        <td>${tx.itemType ? `[بضاعة: ${tx.itemType}] ` : ''}${tx.notes || tx.description || '-'}</td>
      </tr>`;
    });
  }

  const htmlSection = `<div class="person-card">
    <div class="person-card-header">
      <div>
        <div class="person-name">${supplier.name} ${supplier.companyName ? `(${supplier.companyName})` : ''}</div>
        <div class="person-phone">رقم الهاتف: ${cleanPhone} | تاريخ التسجيل: ${cleanCreatedAt}</div>
      </div>
      <div class="person-amount-box">
        <span class="amount-value">${formatNumber(supplier.amount, numberFormat)} د.ع</span>
        <span class="amount-label">الرصيد المستحق القائم</span>
      </div>
    </div>
    <div style="padding: 8px 12px; background: #fff;">
      <table class="tx-table">
        <thead>
          <tr>
            <th style="width: 25px;">#</th>
            <th style="width: 100px;">نوع الحركة</th>
            <th style="width: 110px;">المبلغ</th>
            <th style="width: 95px;">التاريخ</th>
            <th>الملاحظات والتفاصيل</th>
          </tr>
        </thead>
        <tbody>
          ${txRows}
        </tbody>
      </table>
    </div>
  </div>`;

  printSystemPdfReport(
    {
      title: `كشف حساب مورد / شركة - ${supplier.name}`,
      subtitle: `رقم الهاتف: ${cleanPhone} ${supplier.itemType ? `| السلعة: ${supplier.itemType}` : ''}`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor: 'amber',
    },
    htmlSection
  );
}

/**
 * Export Single Installment PDF Statement
 */
export function exportSingleInstallmentPdf(
  installment: InstallmentRecord,
  currentUser?: User | null,
  storeName?: string,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const branchName = currentUser ? getUserBranchDisplayName(currentUser) : (storeName || 'الفرع الرئيسي');
  const userName = currentUser ? getUserDisplayName(currentUser) : 'مدير النظام';

  const cleanRegDate = installment.registrationDate ? installment.registrationDate.split('T')[0].replace(/-/g, '/') : '-';
  const cleanNextDue = installment.nextDueDate ? installment.nextDueDate.split('T')[0].replace(/-/g, '/') : '-';
  const cleanPhone = installment.phone ? installment.phone.replace(/[^0-9]/g, '') : 'غير مسجل';

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 14px;">
    <div style="background: #fdf4ff; border: 1px solid #f5d0fe; padding: 10px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #701a75; font-weight: 700;">إجمالي مبلغ العقد</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #581c87;">${formatNumber(installment.totalAmount, numberFormat)} د.ع</div>
    </div>
    <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 10px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #14532d; font-weight: 700;">المُسدّد والدفعة الأولى</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #15803d;">${formatNumber(installment.totalAmount - installment.remainingAmount, numberFormat)} د.ع</div>
    </div>
    <div style="background: #fff1f2; border: 1px solid #fecdd3; padding: 10px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #881337; font-weight: 700;">المتبقي للتحصيل</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #be123c;">${formatNumber(installment.remainingAmount, numberFormat)} د.ع</div>
    </div>
  </div>`;

  const payments = installment.payments || [];
  let txRows = '';
  if (payments.length === 0) {
    txRows = `<tr><td colspan="5" style="text-align:center; color:#64748b; padding:12px;">لا توجد دفعات تسديد قسط مسجلة لهذا العقد بعد</td></tr>`;
  } else {
    payments.forEach((p, pIdx) => {
      const cleanDate = p.date ? p.date.split('T')[0].replace(/-/g, '/') : '-';
      txRows += `<tr>
        <td><strong>${formatNumber(pIdx + 1, numberFormat)}</strong></td>
        <td><span class="tx-type-pay">تسديد قسط</span></td>
        <td><strong>+${formatNumber(p.amount, numberFormat)} د.ع</strong></td>
        <td>${cleanDate}</td>
        <td>${p.notes || '-'}</td>
      </tr>`;
    });
  }

  const htmlSection = `<div class="person-card">
    <div class="person-card-header">
      <div>
        <div class="person-name">${installment.name} <span style="font-size: 8.5pt; color: #0369a1; font-weight: 700;">[السلعة: ${installment.item}]</span></div>
        <div class="person-phone">رقم الهاتف: ${cleanPhone} | تاريخ العقد: ${cleanRegDate} | الاستحقاق القادم: ${cleanNextDue}</div>
      </div>
      <div class="person-amount-box">
        <span class="amount-value">${formatNumber(installment.remainingAmount, numberFormat)} د.ع</span>
        <span class="amount-label">المتبقي من القسط</span>
      </div>
    </div>
    <div style="padding: 8px 12px; background: #fff;">
      <table class="tx-table">
        <thead>
          <tr>
            <th style="width: 25px;">#</th>
            <th style="width: 100px;">نوع الحركة</th>
            <th style="width: 110px;">المبلغ المسدد</th>
            <th style="width: 95px;">التاريخ</th>
            <th>الملاحظات والتفاصيل</th>
          </tr>
        </thead>
        <tbody>
          ${txRows}
        </tbody>
      </table>
    </div>
  </div>`;

  printSystemPdfReport(
    {
      title: `كشف حساب عقد قسط - ${installment.name}`,
      subtitle: `السلعة: ${installment.item} | رقم الهاتف: ${cleanPhone}`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor: 'emerald',
    },
    htmlSection
  );
}

/**
 * Export Suppliers List PDF Report
 */
export function exportSuppliersPdfReport(
  suppliers: Supplier[],
  currentUser?: User | null,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const branchName = currentUser ? getUserBranchDisplayName(currentUser) : 'الفرع الرئيسي';
  const userName = currentUser ? getUserDisplayName(currentUser) : 'مدير النظام';

  let totalOwed = 0;
  suppliers.forEach((s) => {
    totalOwed += Number(s.amount) || 0;
  });

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 14px;">
    <div style="background: #fffbe3; border: 1px solid #fef08a; padding: 10px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #713f12; font-weight: 700;">إجمالي مستحقات الموردين القائمة</span>
      <div style="font-size: 12pt; font-weight: 800; color: #a16207;">${formatNumber(totalOwed, numberFormat)} د.ع</div>
    </div>
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #475569; font-weight: 700;">إجمالي عدد الموردين والشركات</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #334155;">${formatNumber(suppliers.length, numberFormat)} مورد</div>
    </div>
  </div>`;

  let htmlSections = '';
  if (suppliers.length === 0) {
    htmlSections = '<div style="text-align: center; padding: 20px; color: #64748b;">لا يوجد موردين مسجلين</div>';
  } else {
    suppliers.forEach((sup) => {
      const cleanPhone = sup.phone ? sup.phone.replace(/[^0-9]/g, '') : 'غير مسجل';
      const cleanCreatedAt = sup.createdAt ? sup.createdAt.split('T')[0].replace(/-/g, '/') : '-';
      const history = sup.history || [];

      let txRows = '';
      if (history.length === 0) {
        txRows = `<tr><td colspan="5" style="text-align:center; color:#64748b; padding:8px;">لا توجد حركات مسجلة لهذا المورد</td></tr>`;
      } else {
        history.slice(-10).reverse().forEach((tx, idx) => {
          const isPay = tx.type === 'pay_supplier';
          const typeLabel = isPay ? 'تسديد دفعة' : 'قيد بضاعة/دين';
          const typeClass = isPay ? 'tx-type-pay' : 'tx-type-add';
          const amountPrefix = isPay ? '-' : '+';
          const cleanDate = tx.date ? tx.date.split('T')[0].replace(/-/g, '/') : '-';

          txRows += `<tr>
            <td><strong>${formatNumber(idx + 1, numberFormat)}</strong></td>
            <td><span class="${typeClass}">${typeLabel}</span></td>
            <td><strong>${amountPrefix}${formatNumber(tx.amount, numberFormat)} د.ع</strong></td>
            <td>${cleanDate}</td>
            <td>${tx.notes || tx.description || '-'}</td>
          </tr>`;
        });
      }

      htmlSections += `<div class="person-card">
        <div class="person-card-header">
          <div>
            <div class="person-name">${sup.name} ${sup.companyName ? `(${sup.companyName})` : ''}</div>
            <div class="person-phone">رقم الهاتف: ${cleanPhone} | السلعة: ${sup.itemType || 'غير محدد'} | تاريخ التسجيل: ${cleanCreatedAt}</div>
          </div>
          <div class="person-amount-box">
            <span class="amount-value">${formatNumber(sup.amount, numberFormat)} د.ع</span>
            <span class="amount-label">الرصيد المستحق</span>
          </div>
        </div>
        <div style="padding: 8px 12px; background: #fff;">
          <table class="tx-table">
            <thead>
              <tr>
                <th style="width: 25px;">#</th>
                <th style="width: 100px;">نوع الحركة</th>
                <th style="width: 110px;">المبلغ</th>
                <th style="width: 95px;">التاريخ</th>
                <th>الملاحظات والتفاصيل</th>
              </tr>
            </thead>
            <tbody>
              ${txRows}
            </tbody>
          </table>
        </div>
      </div>`;
    });
  }

  printSystemPdfReport(
    {
      title: 'تقرير كشف حسابات الموردين والشركات الكامل',
      subtitle: `إجمالي عدد الموردين: ${formatNumber(suppliers.length, numberFormat)} مورد`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor: 'amber',
    },
    htmlSections
  );
}

/**
 * Export Installments List PDF Report
 */
export function exportInstallmentsPdfReport(
  installments: InstallmentRecord[],
  currentUser?: User | null,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const branchName = currentUser ? getUserBranchDisplayName(currentUser) : 'الفرع الرئيسي';
  const userName = currentUser ? getUserDisplayName(currentUser) : 'مدير النظام';

  let totalValue = 0;
  let totalRemaining = 0;
  installments.forEach((inst) => {
    totalValue += Number(inst.totalAmount) || 0;
    totalRemaining += Number(inst.remainingAmount) || 0;
  });
  const totalPaid = totalValue - totalRemaining;

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 14px;">
    <div style="background: #fdf4ff; border: 1px solid #f5d0fe; padding: 10px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #701a75; font-weight: 700;">مجموع قيمة عقود الأقساط</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #581c87;">${formatNumber(totalValue, numberFormat)} د.ع</div>
    </div>
    <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 10px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #14532d; font-weight: 700;">إجمالي المحصل والمقدمات</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #15803d;">${formatNumber(totalPaid, numberFormat)} د.ع</div>
    </div>
    <div style="background: #fff1f2; border: 1px solid #fecdd3; padding: 10px; border-radius: 8px; text-align: center;">
      <span style="font-size: 8pt; color: #881337; font-weight: 700;">المتبقي المطلوب تحصيله</span>
      <div style="font-size: 11.5pt; font-weight: 800; color: #be123c;">${formatNumber(totalRemaining, numberFormat)} د.ع</div>
    </div>
  </div>`;

  let htmlSections = '';
  if (installments.length === 0) {
    htmlSections = '<div style="text-align: center; padding: 20px; color: #64748b;">لا توجد معاملات أقساط مسجلة</div>';
  } else {
    installments.forEach((inst) => {
      const cleanPhone = inst.phone ? inst.phone.replace(/[^0-9]/g, '') : 'غير مسجل';
      const cleanRegDate = inst.registrationDate ? inst.registrationDate.split('T')[0].replace(/-/g, '/') : '-';
      const cleanNextDue = inst.nextDueDate ? inst.nextDueDate.split('T')[0].replace(/-/g, '/') : '-';
      const payments = inst.payments || [];

      let txRows = '';
      if (payments.length === 0) {
        txRows = `<tr><td colspan="5" style="text-align:center; color:#64748b; padding:8px;">لا توجد دفعات تسديد مسجلة لهذا العقد بعد</td></tr>`;
      } else {
        payments.forEach((p, idx) => {
          const cleanDate = p.date ? p.date.split('T')[0].replace(/-/g, '/') : '-';
          txRows += `<tr>
            <td><strong>${formatNumber(idx + 1, numberFormat)}</strong></td>
            <td><span class="tx-type-pay">تسديد قسط</span></td>
            <td><strong>+${formatNumber(p.amount, numberFormat)} د.ع</strong></td>
            <td>${cleanDate}</td>
            <td>${p.notes || '-'}</td>
          </tr>`;
        });
      }

      htmlSections += `<div class="person-card">
        <div class="person-card-header">
          <div>
            <div class="person-name">${inst.name} <span style="font-size: 8.5pt; color: #0369a1; font-weight: 700;">[السلعة: ${inst.item}]</span></div>
            <div class="person-phone">رقم الهاتف: ${cleanPhone} | تاريخ العقد: ${cleanRegDate} | الاستحقاق القادم: ${cleanNextDue}</div>
          </div>
          <div class="person-amount-box">
            <span class="amount-value">${formatNumber(inst.remainingAmount, numberFormat)} د.ع</span>
            <span class="amount-label">المتبقي من القسط</span>
          </div>
        </div>
        <div style="padding: 8px 12px; background: #fff;">
          <table class="tx-table">
            <thead>
              <tr>
                <th style="width: 25px;">#</th>
                <th style="width: 100px;">نوع الحركة</th>
                <th style="width: 110px;">المبلغ المسدد</th>
                <th style="width: 95px;">التاريخ</th>
                <th>الملاحظات والتفاصيل</th>
              </tr>
            </thead>
            <tbody>
              ${txRows}
            </tbody>
          </table>
        </div>
      </div>`;
    });
  }

  printSystemPdfReport(
    {
      title: 'تقرير عقود نظام الأقساط المالي الشامل',
      subtitle: `إجمالي المعاملات: ${formatNumber(installments.length, numberFormat)} عقد`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor: 'purple',
    },
    htmlSections
  );
}

